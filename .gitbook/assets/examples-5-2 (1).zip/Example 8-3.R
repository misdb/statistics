# Example 8-3

library(Rstat)

# 1. Cumulative Distribution of Standard Normal Distribution : Table & Graph
# 0~2.49, unit : 0.01, 10 columns

pv <- matrix(pnorm(0:299/100), ncol=10, byrow=T)
colnames(pv) <- 0:9/100; rownames(pv) <- 0:29/10

print(round(pv, 4))

# 2.Cumulative Probability of Standard Normail Distribution
zp <- seq(-2, 2, by=0.5)
snorm.cdf(zp)

# 3. 

# X-axiz
xv <- (-90:90)/20
# Standard Normal Dist.
fx <- dnorm(x)

# P(-1<Z<1), P(-2<Z<2),P(-3<Z<3),P(-4<Z<4)
win.graph(7,6); par(mfrow=c(2,2))

# 4 iterations
for (k in 1:4) {
     plot(x, fx, type="n", main=paste0("P(", -k, "<Z<", k, ")"), 
          ylab= "f(x)", xlab="X")
     cord.x <- c(-k, seq(-k, k, 0.01), k)
     cord.y <- c(0, dnorm(seq(-k, k, 0.01)), 0)
     polygon(cord.x, cord.y, col='lightcyan')
     abline(h=0)

     px <- pnorm(k) - pnorm(-k)
     text(0, 0.1, labels=paste0("P(", -k, "<Z<", k, ")\n", round(px,4)))
     lines(x, fx, lwd=2, col=2)
}

# 4.Cumulative Probability of Standard Normail Distribution
zp <- 1:4
snorm.prob(zp)


