# Example 8-15

library(Rstat)

# df
nu <- c(1, 5, 10, 30)

# 1. prob density comparison function : tnorm.comp()
tnorm.comp(nu)


