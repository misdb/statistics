# Example 8-9

library(Rstat)

# 1. Using pbinom(x, n, p)
# P(X <= 4)
pbinom(4, 25, 0.2)

# 2. approximately normal distribution ==> occur error
# E(X)=np= 25*0.2 = 5, V(X) = npq = 25 * 0.2 * 0.8 = 4
# P(X <= 4) = P( (X-5)/2 < (4-5)/2 ) = P(Z <= -0.5) 
pnorm(4, 5, 2)
pnorm(-0.5)

# 3. Continuity correction approximately normal dist.
P( X<= 4) = P(X <= 4.5) = P(Z <= -0.25)
pnorm(4.5, 5, 2)
pnorm(-0.25)
