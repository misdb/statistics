# Example 8-4

library(Rstat)

# 1.Cumulative Probability of Standard Normail Distribution
zp <- 1:4
snorm.prob(zp)