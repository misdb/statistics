# Example 8-8

library(Rstat)


# 1. Using Standardization
# P(40 < X < 60) = P((40-50)/sqrt(16) < X < (60-50)/sqrt(16)) = P(-2.5 < Z < 2.5)
pnorm(2.5) - pnorm(-2.5)

# 2. Direct Computation
pnorm(60, 50, 4) - pnorm(40, 50, 4)

