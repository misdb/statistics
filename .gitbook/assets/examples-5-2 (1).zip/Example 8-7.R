# Example 8-7

library(Rstat)


# 1. Using Standardization
# P(X>Y) = P(Y-X <0), Y-X ~ N(1.5, 0.4^2 + 0.3^2)
# P(Y-X < 0) = P(Z < (0-1.5)/sqrt(.25)) = P(Z<-3)
pnorm(-3)

# 2. Direct Computation
pnorm(0, 21.5 - 20, sqrt(0.4^2 + 0.3^2))

