# Example 8-10

library(Rstat)

# 1. Using pbinom(x, n, p)
# P( 40 <= X <= 45) = P( X <= 45 ) - P( X <= 39 )
# n=100, p = 3/6 = 0.5
pbinom(45, 100, 0.5) - pbinom(39, 100, 0.5)

# 2. approximately normal distribution ==> occur error
# E(X)=np= 100*0.5 = 50, V(X) = npq = 100 * 0.5 * 0.5 = 25
# P( 40 <= X <= 45) = P( (40-50)/5 <= Z <= (45-50)/5 ) = P( -2 <= Z <= -1) 
pnorm(45, 50, 5) - pnorm(40, 50, 5) 
pnorm(-1) - pnorm(-2)

# 3. Continuity correction approximately normal dist.
P( 40 <= X <= 45) = P( 39.5 <= X <= 45.5 ) = P( -2.1 <= Z <= -0.9 )
pnorm(45.5, 50, 5) - pnorm(39.5, 50, 5)
pnorm(-0.9) - pnorm(-2.1)

