# Example 7-8

library(Rstat)

# alpha * theta = 10, alpha * theta^2 = 50 => alpha = 2, theta = 5

EX <- 10; VX <- 50

alp <- EX^2 / VX
th <- EX / alp

# 1. 
a <- pgamma(3, alp, 1/th, lower=F); a

# 2.
b <- pgamma(8, alp, 1/th, lower=F); b

# 3.  P(5+3|8)
c <- b / pgamma(5, alp, 1/th, lower=F); c



