# Example 7-4

library(Rstat)

# 1. probability density function and cumulative function of X
theta <- 10000                 # theta in time
lamb <- 1/theta                # value of lambda

# qunatile of Cumulative Prob. = 1 - 0.9  in hours
qexp(1-0.9, lamb)
