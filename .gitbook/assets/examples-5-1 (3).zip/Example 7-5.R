# Example 7-5

library(Rstat)

# 1. Definition of the function
lamb <- function(r) pexp(10000, r, lower=F) - 0.9

# 2. Find the solution using `uniroot()` function
uniroot(lamb, c(0,1), tol = 1E-10)[[1]]    # range : (0,1), limit of erroe : 1E-10
