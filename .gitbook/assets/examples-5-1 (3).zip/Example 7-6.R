# Example 7-6

library(Rstat)

#-------------------------------------
# In case of theta=1 and alpha=0.5
#-------------------------------------

# 1. probability density function and cumulative function of X
alp <- 0.5        # alpha
rate <- 1         # theta

cont.mpdf("gamma", 0, 8, para=alp, para2=rate, ymax=1.2)  # cont.mpdf("gamma",  ,,,) : exponential distribution


#------------------------------------------------
# In case of theta=1 and alpha=c(0.5, 1, 2, 3)
#------------------------------------------------

# 1. probability density function and cumulative function of X
alp <- c(0.5, 1, 2, 3)        # alpha
rate <- 1                     # theta

cont.mpdf("gamma", 0, 8, para=alp, para2=rate, ymax=1.2)  # cont.mpdf("gamma",  ,,,) : exponential distribution

