# Example 6-6

#--------------------------------
# in case of mean(L) = 2
#--------------------------------

# 1. Prob. Distribution of X
L <- 2
n <- 15

x <- 0:n
fx <- dpois(x, L)

# 2. Title of Plot and Using `disc.exp()` function for E(X), V(X), and Plot
mt1 <- paste0("Poisson(", L, ")")
disc.exp(x, fx, mt = mt1, plot=TRUE)


#--------------------------------
# in case of mean(L) = c(2, 5, 8)
#--------------------------------

# 1. Prob. Distribution of X
L <- c(2, 5, 8)
n <- 25

x <- 0:n

fx2 <- list()
for (i in 1:length(L)) fx2[[i]] <- dpois(x, L[i])

# 2. Title of Plot and Using `disc.mexp()` function for E(X), V(X), and Plot
mt1 <- paste0("Poisson(", L, ")")
disc.mexp(x, fx2, mt = mt1, plot=TRUE)


# 3. Comparison of 'Binomial Distribution' and 'Poisson Distribution'
mt13 <- paste0("B(10) vs Pois(", L, ")")
x <- 0:10

fx2 <- list()
for (i in 1:length(L)) fx2[[i]] <- dpois(x, L[i])

disc.mexp(x, fx2, fx1, mt = mt13, plot=TRUE)  # 'fx1' from 'Example 6-2'


