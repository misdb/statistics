# Example 6-5

library(Rstat)

N <- 1000
S <- 1000 * 0.05
n <- 30

# 1. Prob. Distribution
x <- 0:30
fx <- dhyper(x, S, N-S, n)

# 2. E(X) and V(X) of Discrete Random Variable : disc.exp(x, fx)
disc.exp(x, fx)

# 3. P(X=3) : dhyper(3, S, N-S, n)
x <- 3
dhyper(x, S, N-S, n)

# 4. P(X<=3) : sum(dhyper(0:3, S, N-S, n)) = phyper(3, S, N-S, n)
# 1) P(X<=3) = f(0) + f(1) + f(2) + f(3)
x <- 0:3    
sum(dhyper(x, S, N-S, n))

# 2) P(X<=3) = F(3)
x <- 3
phyper(x, S, N-S, n)