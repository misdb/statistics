# Example 6-1

library(Rstat)

# 1. probability distribution of X
x <- 1:20
p <- rep(1, 20)

# 2. E(X), V(X)
disc.exp(x, p)
disc.exp(x, p, plot=TRUE)

# 3. P(X>=15)
sum(x>=15) / length(x)

