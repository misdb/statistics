# Example 6-4

library(Rstat)

#--------------------------------------------
# in case of success size (S = 10)
#--------------------------------------------

# Population (N), Sample Size (n), range of X (0:n)
N <- 50
S <- 10
n <- 10
x <- 0:n

# Define empty list()
# fx <- list()

# Probability Mass Function : 'dhyper()'
fx1 <- dhyper(x, S, N-S, n)

# Summation of Each Distribution
sapply(fx1, sum)

# Title of Graph and Run 'disc.exp()'
title <- paste0("HG(10, 50,", S, ")")
disc.exp(x, fx1, mt = title)


#--------------------------------------------
# in case of success sizes (S = c(10, 25, 40))
#--------------------------------------------

# Population (N), Sample Size (n), range of X (0:n)
N <- 50
S <- c(10, 25, 40)
n <- 10
x <- 0:n

# Define empty list()
fx2 <- list()

# Probability Mass Function : 'dhyper()'
for (i in 1:3) fx2[[i]] <- dhyper(x, S[i], N-S[i], n)

# Summation of Each Distribution
sapply(fx2, sum)

# Title of Graph and Run 'disc.mexp()'
title <- paste0("HG(10, 50,", S, ")")
disc.mexp(x, fx2, mt = title)

