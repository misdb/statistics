# Example 6-8

#--------------------------------
# in case of p=0.1
#--------------------------------

# 1. Prob. Distribution of X
x <- 0:50
p <- 0.1

fx <- dgeom(x-1, p)  # dgeom() uses the number of failure. so using (x-1) insted of x

# 2. Title of Plot and Using `disc.exp()` function for E(X), V(X), and Plot
disc.exp(x, fx, plot=TRUE)

#--------------------------------
# in case of p = c(0.1, 0.3, 0.5)
#--------------------------------

# 1. Prob. Distribution of X
x <- 0:50
p <- c(0.1, 0.3, 0.5)

fx3 <- list()
for (i in 1:length(p)) fx3[[i]] <- dgeom(x-1, p[i])

# 2. Title of Plot and Using `disc.mexp()` function for E(X), V(X), and Plot
mt3 <- paste0("Geometric(", p, ")")

win.graph(9, 3)
par(mfrow=c(1,3))
par(mar=c(3,4,4,2))

for (k in 1:length(p)) plot(1:50, fx3[[k]][1:50], type="h", main=mt3[k],
                            ylab = "f(x)", xlab = "", lwd=3, col=2)
