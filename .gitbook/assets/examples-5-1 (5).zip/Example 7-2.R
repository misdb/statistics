# Example 7-2

library(Rstat)

#-------------------------
# In case of lambda = 1
#-------------------------

# 1. probability density function and cumulative function of X

lamb <- 1                                 # value of lambda

cont.mpdf("exp", 0, 3, para=lamb, ymax=5)  # cont.mpdf("exp",  ,,,) : exponential distribution


#-------------------------
# In case of lambda = c(1,2,3,4,5)
#-------------------------

# 1. probability density function and cumulative function of X

lamb <- c(1, 2, 3, 4, 5)                                 # values of lambda

cont.mpdf("exp", 0, 3, para=lamb, ymax=5)  

