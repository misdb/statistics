# Example 7-Expon : Rstat Functions for Exponential Distribution

library(Rstat)

# 1. Probability Density Function of X
fx <- function(x) dexp(x, 3)*(x>0)

# lower-limit(ll), upper-limit(ul)
ll <- 0.001
up <- 3
cont.exp(fx, ll, ul, prt=TRUE, plot=TRUE)

# 3. P(X<=q) : pexp() => Cumulative Distribution Function
q <- (0:30)/10
fx2 <- pexp(q, 3, lower.tail=TRUE)
plot(q, fx2)

cont.cdf(fx, 0, 3, xs=c(0.1, 0.3, 0.6, 0.9))

# 4. P(X<=q) = p1 : qexp() => find q (Quantile)
p1 <- c(0.01, 0.05, 0.10, 0.90, 0.95, 0.99)
fx3 <- qexp(p1, rate=3, lower.tail=TRUE)
plot(p1, fx3)

# 5. random number generator : rexp()
# k = number of random numbers
k <- 100
fx4 <- rexp(k, rate=3)
hist(fx4, breaks=10)




