# Example 7-9

library(Rstat)

old <- seq(0, 15, by=5)
alp <- 5; th <- 2
dcol <- c("red", "blue", "green2", "purple")

x <- 0:200/10
denom <- pgamma(old, alp, scale=th, lower.tail=F); denom

# Survival Function
win.graph(7, 5)
plot(x, pgamma(x, alp, scale=th, lower.tail=F), 
     type="l", lwd=2, col=dcol[1], 
     main="(Conditional) Survival Function of Gamma Distribution",
     ylab="R(x)", ylim=c(0,1))
grid(col=3)
for (i in 2:4) lines(x, pgamma(x+old[i], alp, scale=th, lower.tail=F)/denom[i],
                     lwd=2, col=dcol[i])
text(5, pgamma(5+old, alp, scale=th, lower.tail=F)/denom, 
     labels=paste0("Age=", old))
