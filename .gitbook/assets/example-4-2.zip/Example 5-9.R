# Example 5-9

library(Rstat)

# Probability distribution of X : [uniform distribution]
x <- 1:6
f <- rep(1,6)

y <- 100 * x - 400

# E(X), V(X), D(X)
disc.exp(y, f)

# E(X), V(X), D(X) and Plot
disc.exp(y, f, prt=TRUE, plot=TRUE)
