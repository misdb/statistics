#---------------------
# Problem I
#---------------------

library(Rstat)

# Data Set of Problem I
p1 <- c(32.5, 52.5, 40, 42.5, 12.5, 57.5, 67.5, 32.5, 57.5, 35,
45, 40, 72.5, 45, 47.5, 70, 45, 42.5, 50, 40, 57.5, 42.5,
57.5, 42.5, 35, 35, 32.5, 25, 67.5, 57.5, 37.5, 25)

# 1. median
median(p1)

# 2. Mode
y <- table(p1)
names(which.max(y))

# 3. mean
mean(p1)

# 4. Geometric Mean
n <- length(p1); n
g_mean <- prod(p1)^(1/n); g_mean

# 5. Harmonic Mean
h_mean <- mean(p1^(-1))^(-1)
h_mean


#---------------------
# Problem II
#---------------------

library(Rstat)

# Data Set of Problem II
p2 <- c(42.5, 25, 37.5, 40, 27.5, 30, 35, 40, 25, 42.5, 
37.5, 52.5, 37.5, 60, 65, 30, 32.5, 57.5, 32.5, 
50, 55, 55, 40, 32.5, 35, 47.5)

# 1. Range
range(p2)
diff(range(p2))

# 2. Variance
var(p2)

# 3. IQR
IQR(p2)

# 4. Quantile
quantile(p2)

# 5. 5%th Quantile
quantile(p2, probs=0.10)


#---------------------
# Problem III
#---------------------

library(Rstat)

# Sample Space

# 1) Method 1
S2 <- rolldie.sum(3)
list(S2)

# 1) Method 2
S1 <- rolldie2(3); element(S1)
S2 <- subset(S1, (X1 <=X2 & X1<=X3 & X2<=X3) ); element(S2); nrow(S2)

# 1. Number of Elements 
nrow(S2)

# 2. Event A1 : ( sum of numbers >= 15 ) 
#    and P(A1)
A1 <- subset(S2, (X1+X2+X3) >= 15); element(A1); nrow(A1)
P1 <- nrow(A1)/nrow(S2); P1
pprt(A1, nrow(S2))

# 3. Event A2 : ( sum of numbers : even number ) 
#    and P(A1)
A2 <- subset(S2, (X1+X2+X3) %% 2 == 0); element(A2); nrow(A2)
P2 <- nrow(A2)/nrow(S2); P2
pprt(A2, nrow(S2))


#---------------------
# Problem IV
#---------------------

# Sample Space S = Tossing coin 4 times

library(Rstat)
S <- tosscoin2(4); element(S); nrow(S)

# Event A : number of H >=2, 
# Event B : number of H > number of T
# Event C : number of T >=1

countH <- function(x) sum(x=="H")
countT <- function(x) sum(x=="T")

A <- subset(S, apply(S, 1, countH) >= 2); element(A); nrow(A)
B <- subset(S, apply(S, 1, countH) > apply(S, 1, countT) ); element(B); nrow(B)
C <- subset(S, apply(S, 1, countT) >= 1); element(C); nrow(C)

# P(A), P(B), P(C)
# P(A)
Pa <- nrow(A)/nrow(S); Pa
pprt(A, nrow(S))

# P(B)
Pb <- nrow(B)/nrow(S); Pb
pprt(B, nrow(S))

# P(C)
Pc <- nrow(C)/nrow(S); Pc
pprt(C, nrow(S))

# 1. P(Ac)
Ac <- setdiff2(S, A); element(Ac); nrow(Ac)
PAc <- nrow(Ac) / nrow(S); PAc
pprt(Ac, nrow(S))

# 2. P(ABc)
Bc <- setdiff2(S, B); element(Bc); nrow(Bc)
ABc <- intersect2(A, Bc); element(ABc); nrow(ABc)
PABc <- nrow(ABc) / nrow(S); PABc
pprt(ABc, nrow(S))

# 3. P(AC)
AC <- intersect2(A,C); element(AC); nrow(AC)
PAC <- nrow(AC) / nrow(S); PAC
pprt(AC, nrow(S))

# 4. P(BC)
BC <- intersect2(B,C); element(BC); nrow(BC)
PBC <- nrow(BC) / nrow(S); PBC
pprt(BC, nrow(S))

# 5. P(ABC)
ABC <- intersect2(A, BC); element(ABC); nrow(ABC)
PABC <- nrow(ABC) / nrow(S); PABC
pprt(ABC, nrow(S))

# 6. P(BuC)
BuC <- union2(B, C); element(BuC); nrow(BuC)
PBuC <- nrow(BuC) / nrow(S); PBuC
pprt(BuC, nrow(S))

# 7. P(A|B)
cprt(A, B)

# 8. P(A|C)
cprt(A, C)

# 9. P(A|BC)
cprt(A, BC)

# 10. P(A|BuC)
cprt(A, BuC)


#---------------------
# Problem V
#---------------------

library(Rstat)

# 1. Prob. Density Function
p <- 0.3
n <- 10
X <- 0:n
fx <- dbinom(X, n, p); fx

# 2. E(X), V(X)
disc.exp(X, fx)

# 3. P(2<= X <=4) = P(x<=4) - p(X<=1)
pbinom(4, n, p) - pbinom(1, n, p)

# 4. P(X>=6) = 1 - P(X<=5) = 1 - pbinom(5, n, p)
1- pbinom(5, n, p)

# 5. P(X<= q) = 0.85 : qbinom(0.85, n, p)
qbinom(0.85, n, p)


#---------------------
# Problem VI
#---------------------

library(Rstat)

# 1. Number of Sample Space(SS)
SS <- combn(13, 8)
dim(SS)[2]

# 2. Xb : Number of Blue Balls 
#         dhyper(x, S, N-S, n)
Sb <- 5
N <- 16
n <- 8
Xb <- 0:Sb
fXb <- dhyper(Xb, Sb, N-Sb, n)
round(fXb, 4)

# 3. E(Xb), V(Xb)
disc.exp(Xb, fXb)

# 4. P(Xb <=2) = phyper(2, Sb, N-Sb, n)
phyper(2, Sb, N-Sb, n)

# 5. P(Xb<= q)=0.65 : qhyper(0.65, Sb, N-Sb, n)
qhyper(0.65, Sb, N-Sb, n)



