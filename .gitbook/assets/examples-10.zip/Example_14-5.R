# Example_14-5

library(Rstat)

# Input Data
x <- c(1095, 1110, 1086, 1074, 1098, 1105, 1163, 1124, 1088, 1064)
y <- c(49, 52, 48, 49, 50, 51, 50, 51, 49, 48)

y2 <- y * x /1000; y2

#--------------------
# Method #1

# Scatter Plot
win.graph(7, 5)
plot(x, y2, pch=19, main="Currency Rate : Amount of Export", 
     xlab="Currency Rate", ylab="Amount of Export", ylim=c(50, 60))


# Linear Regression Analysis
rg1 <- lm(y2 ~ x); rg1

# Linear Regression Line
abline(rg1, col=2)

# Display the regression equation
text(1140, 52, 
     labels=paste0("Y = ", round(rg1$coef[[1]], 3), " + ", round(rg1$coef[[2]], 3),
     " * X"), col=4)

# Residuals
segments(x, y2, x, rg1$fit, lty=2, col=4)
text(x, (y2+rg1$fit)/2, labels=expression(epsilon), col=4, pos=4)
     

#--------------------
# Method #2

# Step 6
corr.reg1(x, y2, r0=0.9, step=6)

