# Example_14-2

library(Rstat)

# Importing Dataset of Rstat
data(exa14_1)
exa14_1

# Definition of list class
subject <- c("Korean", "English", "Math", "Social", "Science", "Arts")

#--------------------
# Method #1

dat <- exa14_1

# Test of Correlation => cor.test() function
for (k in 1:6) { ct <- cor.test(dat[[2*k-1]], dat[[2*k]])
                 cat(subject[k], "\tCorr =", round(ct$est, 4), 
                     "\tt-Stat =", round(ct$stat, 4), 
                     "\tP-v =", round(ct$p.val, 4), 
                     "\n\t95% CI = [", round(ct$conf, 4), "]\n")  }

win.graph(9, 6)
par(mfrow=c(2,3))

for (k in 1:6) { ct <- cor.test(dat[[2*k-1]], dat[[2*k]])
                 mr <- max(c(3, abs(ct$stat*1.2)))
                 ttest.plot(ct$stat, ct$para, prng=c(-mr, mr))   }

#--------------------
# Method #2

# corr.mplot() of Rstat package
corr.mplot(X=xd, item=subject, xl = "First Term", yl = "Second Term", step=3:5)
