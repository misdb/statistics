# Example_14-12

library(Rstat)

# Importing Dataset from Rstat Package
data(exa14_10)
colnames(exa14_10) <- c("Grade", "Korean", "Reading")
attach(exa14_10)

#--------------------
# Method #1

# regression anlysis
rg2 <- lm(Grade ~ Korean + Reading); rg2

summary(rg2)      # You can find t-statistic using summary().
                  # summary() shows more details than anova().

#--------------------
# Method #2

xd <- data.frame(Korean, Reading); form <- Grade ~ Korean + Reading

# corr.mreg() function : Step 3
corr.mreg(xd, Grade, form, step=3)


