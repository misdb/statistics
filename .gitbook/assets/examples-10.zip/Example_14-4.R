# Example_14-4

library(Rstat)

# Input Data
x <- c(1095, 1110, 1086, 1074, 1098, 1105, 1163, 1124, 1088, 1064)
y <- c(49, 52, 48, 49, 50, 51, 50, 51, 49, 48)

y2 <- y * x /1000; y2

#--------------------
# Method #1

# (1)
# Test of Correlation => cor.test() function
# cor.test(x, y, alternative = c("two.sided", "less", "greater"), 
#          method = NULL, conf.level = 0.95, continuity = FALSE, ...)

ct2 <- cor.test(x, y2)
ct2

cat("\nSample Corr. Coef. =", round(ct2$est, 4), 
    "\nt-Stat =", round(ct2$stat, 4), 
    "\nP-v =", round(ct2$p.val, 4), 
    "\n95% CI = [", round(ct2$conf, 4), "]\n")

# (2)
n <- length(y)
r0 <- 0.9; rxy2 <- ct2$est
z0 <- sqrt(n-3) * 0.5 * (log((1+rxy2)/(1-rxy2)) - log((1+r0)/(1-r0))); z0
pv <- 2 * min(pnorm(z0), 1-pnorm(z0)); pv

#--------------------
# Method #2

# (1)
# corr.reg1() of Rstat package
corr.reg1(x, y2, step=1:4)

# (2)
corr.reg1(x, y2, r0=0.9, step=3:4)

