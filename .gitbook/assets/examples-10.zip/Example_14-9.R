# Example_14-9

library(Rstat)

# Input Data
x <- c(1095, 1110, 1086, 1074, 1098, 1105, 1163, 1124, 1088, 1064)
y <- c(49, 52, 48, 49, 50, 51, 50, 51, 49, 48)

y2 <- y * x /1000; y2

#--------------------
# Method #1

# Fitness of Regression Model
rg1 <- lm(y2 ~ x)  

# x=1200 -> predicted value
new <- data.frame(x=1200)
predict(rg1, new, interval="confidence")

# predicted interval
predict(rg1, new, interval="prediction")

# define the interval
nd <- data.frame(x=seq(1050, 1200, by=5))

# Confidence Bands and Prediction Bands
conf2 <- predict(rg1, interval="confidence", newdata=nd)
pred2 <- predict(rg1, interval="prediction", newdata=nd)

# Plot
win.graph(7,6)
plot(x, y2, pch=19, main = "Currency Rate : Amount of Export - C.B. and P.B.",
     xlab="Currency Rate", ylab="Amount of Export", xlim=c(1050, 1200), ylim=c(45, 70), )

# Regression Line, CI Curve, PI Curve
abline(rg1, col=4)
abline(v=mean(x), lty=2, col=3)
text(mean(x), 45, labels=expression(bar(x)), pos=4)
matlines(nd$x, conf2[,c("lwr","upr")], col=2, type="p", pch="+")
matlines(nd$x, pred2[,c("lwr","upr")], col=4, type="p", pch=1)
text(1200, pred2[31,], labels=format(pred2[31,], digit=4), pos=c(1,1,3))


#--------------------
# Method #2

# C.I.
# Step 10
corr.reg1(x, y2, kl=="Currency", yl="Export", step=10, x0=1200)

# P.I.
# Step 11
corr.reg1(x, y2, kl=="Currency", yl="Export", step=11, 
          x0=1200, xrng=c(1050, 1200), by=5)


