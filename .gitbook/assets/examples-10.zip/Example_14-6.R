# Example_14-6

library(Rstat)

# Input Data
x <- c(1095, 1110, 1086, 1074, 1098, 1105, 1163, 1124, 1088, 1064)
y <- c(49, 52, 48, 49, 50, 51, 50, 51, 49, 48)

y2 <- y * x /1000; y2

#--------------------
# Method #1

# Regression Analysis
rg1 <- lm(y2 ~ x)  
rg1$coef

#--------------------
# Method #2

# Step 7
corr.reg1(x, y2, kl=="Currency", yl="Export", step=7)

