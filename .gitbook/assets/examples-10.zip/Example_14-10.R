# Example_14-10

library(Rstat)

# Importing Dataset from Rstat Package
data(exa14_10)
colnames(exa14_10) <- c("Grade", "Korean", "Reading")
attach(exa14_10)

#--------------------
# Method #1

# relationships among data
win.graph(7, 6)
pairs(cbind(Korean, Reading, Grade), panel=function(x,y) {
                points(x,y)
                abline(lm(y~x), col='red') })

# regression anlysis
rg2 <- lm(Grade ~ Korean + Reading); rg2


#--------------------
# Method #2

xd <- data.frame(Korean, Reading); form <- Grade ~ Korean + Reading

# corr.mreg() function
corr.mreg(xd, Grade, form, step=0:1)


