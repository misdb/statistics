# Example_14-13

library(Rstat)

# Importing Dataset from Rstat Package
data(exa14_10)
colnames(exa14_10) <- c("Grade", "Korean", "Reading")
attach(exa14_10)

#--------------------
# Method #1

# Step 1) data relationships
pairs( cbind(Korean, Reading, Grade), panel=function(x,y) {
       points(x, y)
       abline(lm(y~x), col='red') } )

# Step 2) Regression Analysis
rg2 <- lm(Grade ~ Korean + Reading)
rg3 <- lm(Grade ~ Korean * Reading)

# Estimated Reg. Coef.
coefficients(rg2)
coefficients(rg3)

# Confidence Bands
confint(rg2, level=0.95)
confint(rg3, level=0.95)

# ANOVA Table
anova(rg2)
anova(rg3)

# Summary
summary(rg2)
summary(rg3)

# Step 3) Comparison of Regression Models
anova(rg2, rg3)

# Step 4) 
par(mfrow=c(2,2))
plot(rg2)



#--------------------
# Method #2
xd <- data.frame(Korean, Reading)
form <- Grade ~ Korean + Reading

xd2 <- data.frame(Korean, Reading, Korean.Reading=Korean*Reading)
form2 <- Grade ~ Korean * Reading

# corr.mreg() function : Step 4 (Regression Analysis)
corr.mreg(xd, Grade, form, xd2, form2, step=4)

# corr.mreg() function : Step 5 (Regression Model Diagnosis)
corr.mreg(xd, Grade, form, xd2, form2, step=5)





