# Example_14-1

library(Rstat)

# Importing Dataset of Rstat
data(exa14_1)
exa14_1

# Definition of list class
subject <- c("Korean", "English", "Math", "Social", "Science", "Arts")

#--------------------
# Method #1

dat <- exa14_1
mt <- paste0("Scatter Plot (", letters[1:6], "} ", subject)
mt
win.graph(9,6)
par(mfrow=c(2,3))

for (k in 1:6) {
     plot(dat[[2*k-1]], dat[[2*k]], pch=19, main=mt[k],
          xlab="First Term", ylab="Second Term")
     abline(lm(dat[[2*k]] ~ dat[[2*k-1]]), lty=2, col=2)  }


#--------------------
# Method #2

xd <- list()
for (k in 1:6) xd[[k]] <- cbind(exa14_1[[2*k -1]], exa14_1[[2*k]])
xd

# corr.mplot() of Rstat package
corr.mplot(X=xd, item=subject, xl = "First Term", yl = "Second Term", step=1:2)
