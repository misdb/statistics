# Example_14-8

library(Rstat)

# Input Data
x <- c(1095, 1110, 1086, 1074, 1098, 1105, 1163, 1124, 1088, 1064)
y <- c(49, 52, 48, 49, 50, 51, 50, 51, 49, 48)

y2 <- y * x /1000; y2

#--------------------
# Method #1

# Fitness of Regression Model
rg1 <- lm(y2 ~ x)  

# Confidence Interval
confint(rg1, level=0.95)

# Hypothesis Test
summary(rg1)$coef   # 1) Slope(X) : p-val < 0.05 => reject Hypothesis.
                    #            There is enough proof that the slope is different from 0.
                    # 2) Intercept : p-val > 0.05 => Accept Hypothesis.
                    #            There is no enough proof that the intercept is different from 0.

#--------------------
# Method #2

# Step 9
corr.reg1(x, y2, kl=="Currency", yl="Export", step=9)

