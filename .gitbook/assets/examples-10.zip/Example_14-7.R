# Example_14-7

library(Rstat)

# Input Data
x <- c(1095, 1110, 1086, 1074, 1098, 1105, 1163, 1124, 1088, 1064)
y <- c(49, 52, 48, 49, 50, 51, 50, 51, 49, 48)

y2 <- y * x /1000; y2

#--------------------
# Method #1

# Fitness of Regression Model
rg1 <- lm(y2 ~ x)  

# Analysis of Variance : 
an1 <- anova(rg1); an1  
# (Result) p-val is too small. ==> Regression Model is significant

# Coef. of Determinant
summary(rg1)$r.sq


#--------------------
# Method #2

# Step 8
corr.reg1(x, y2, kl=="Currency", yl="Export", step=8)

