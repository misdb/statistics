# Example_14-3

library(Rstat)

# Input Data
x <- c(1095, 1110, 1086, 1074, 1098, 1105, 1163, 1124, 1088, 1064)
y <- c(49, 52, 48, 49, 50, 51, 50, 51, 49, 48)


#--------------------
# Method #1

# Test of Correlation => cor.test() function
# cor.test(x, y, alternative = c("two.sided", "less", "greater"), 
#          method = NULL, conf.level = 0.95, continuity = FALSE, ...)

ct <- cor.test(x, y)
ct

cat("\nSample Corr. Coef. =", round(ct$est, 4), 
    "\nt-Stat =", round(ct$stat, 4), 
    "\nP-v =", round(ct$p.val, 4), 
    "\n95% CI = [", round(ct$conf, 4), "]\n")


#--------------------
# Method #2

# corr.reg1() of Rstat package
corr.reg1(x, y, step=1:4)
