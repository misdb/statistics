# Example_14-12_add
# (Problem) When Studying 'Korean' Time (in Hours)= 5, 'Reading' Time = 5, 
#           Find CI and PI for Grade.

library(Rstat)

# Importing Dataset from Rstat Package
data(exa14_10)
colnames(exa14_10) <- c("Grade", "Korean", "Reading")
attach(exa14_10)

#--------------------
# Method #2

nd <- data.frame(Korean=5, Reading=5, nesd=nd);

# corr.mreg() function : Step 6
# Confidence Intervals and Prediction Intervals at x=newd
corr.mreg(xd, Grade, form, step=6, newd=nd)

# Step 7
# Confidence and Prediction Bands of Grade given Korean
corr.mreg(xd, Grade, form, step=7, xrng=c(0,15), pvx=1, nx=30)

# Confidence and Prediction Bands of Grade given Reading
corr.mreg(xd, Grade, form, step=7, xrng=c(0,15), pvx=2, nx=30)


