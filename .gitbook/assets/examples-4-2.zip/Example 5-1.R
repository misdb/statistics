# Example 5-1

library(Rstat)

# 1) Sample Space
S <- tosscoin2(3)

# 2) definition of function 'countH' and 'countT '
countH <- function(x) sum(x=="H")
countT <- function(x) sum(x=="T")

# 3) definition of X
XT <- apply(S, 1, countT)*100; XT
XH <- apply(S, 1, countH)*100; XH
X <- XT - XH; X

# 4) prob. distribution of X
p <- data.frame(table(X)/nrow(S))
p

# 5) E(X), Var(X) and Plot
xv <- unique(X); xf <- p$Freq

disc.exp(xv, xf, plot=TRUE)

