# Example 5-7

library(Rstat)

# Probability distribution of X : [uniform distribution]
x <- 1:6
f <- rep(1,6)

# E(X), V(X), D(X)
disc.exp(x, f)
