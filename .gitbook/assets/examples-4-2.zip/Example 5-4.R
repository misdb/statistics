# Example 5-4

library(Rstat)

# Probability distribution function of X 
pdf <- function(x) 2* exp(-2*x)*(x>0)

y <- function(x) 3*x-3
yp <- function(x) y(x)*pdf(x)

# E(y)
integrate(yp, 0, Inf)[[1]]

