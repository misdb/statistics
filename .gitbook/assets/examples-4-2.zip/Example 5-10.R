# Example 5-10

library(Rstat)

#-------------------
# Method 1
#-------------------

# Probability distribution function of X 
pdf <- function(x) 2* exp(-2*x)*(x>0)
y <- function(x) 20*x - 10

# E(X)
yp <- function(x) y(x)*pdf(x)
Ey <- integrate(yp, 0, Inf)[[1]]

# V(X)
y2p <- function(x) y(x)^2*pdf(x)
Ey2 <- integrate(y2p, 0, Inf)[[1]]
Vy <- Ey2 - Ey^2

# Print the Result
cat("E(Y) = ", round(Ey, 2), "\n")
cat("Var(Y) = ", round(Ey2, 4), " - ", round(Ey, 4), "^2 = ", 
round(Vy, 4), "\n")


#-------------------
# Method 2
#-------------------

# Probability distribution function of X 
pdf <- function(x) 2* exp(-2*x)*(x>0)

# Y = aX + b
# E(X) = a*E(X) + B; V(X) = a^2 * V(X)
# Y = (20 X - 10)
a <- 20; b <- -10

# function 'cont.exp()' :
# Expected Values of Continuous Random Variables

# E(X), Var(X), Plot
stat <- cont.exp(pdf, 0, 10, prt=TRUE, plot=TRUE)

Ey <- a * stat[[1]] + b
cat("E(Y) = ", a, "* E(X) + (", b, ") \n     = ", a, "*", stat[[1]], "+ (", b, ") = ", round(Ey, 4), "\n\n")

Vy <- a^2 * (stat[[2]]^2)
cat("V(Y) =", a^2,"* V(Y) \n     =", a^2, "*", round(stat[[2]],4), "=", round(Ey, 4), "\n")

