# Example 5-8

library(Rstat)

#-------------------
# Method 1
#-------------------

# Probability distribution function of X 
pdf <- function(x) 2* exp(-2*x)*(x>0)

# E(X)
xp <- function(x) x*pdf(x)
Ex <- integrate(xp, 0, Inf)[[1]]

# V(X)
x2p <- function(x) x^2*pdf(x)
Ex2 <- integrate(x2p, 0, Inf)[[1]]
Vx <- Ex2 - Ex^2

# Print the Result
cat("E(X) = ", Ex, "\n")
cat("Var(X) = ", round(Ex2, 4), " - ", round(Ex, 4), "^2 = ", 
round(Vx, 4), "\n")


#-------------------
# Method 2
#-------------------

# Probability distribution function of X 
pdf <- function(x) 2* exp(-2*x)*(x>0)

# function 'cont.exp()' :
# Expected Values of Continuous Random Variables

# E(X), Var(X), Plot
cont.exp(pdf, 0, 10, prt=TRUE, plot=TRUE)
