# Example 5-2

library(Rstat)

# Probability distribution function of X 
pdf <- function(x) 2* exp(-2*x)*(x>0)
xp <- function(x) x*pdf(x)

# E(X)
integrate(xp, 0, Inf)[[1]]

