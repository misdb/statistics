# Example 5-3

library(Rstat)

# 1) Sample Space
S <- tosscoin2(3)

# 2) definition of function 'countT '
countT <- function(x) sum(x=="T")

# 3) definition of X
X <- apply(S, 1, countT); X
y <- X^2; y

# 4) prob. distribution of y
p <- data.frame(table(y)/nrow(S)); p

# 5) E(y), Var(y) and Plot
y <- unique(y); f <- p$Freq

disc.exp(y, f, plot=TRUE)

