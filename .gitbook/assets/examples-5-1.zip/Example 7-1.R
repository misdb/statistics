# Example 7-1

library(Rstat)

# 1. probability distribution of X

fx <- function(x) dunif(x, 0, 1)
fy <- function(y) dunif(y, 2, 6)

# 2. E(X), V(X)
cont.exp(fx, -0.2, 1.2, prt=T)

# 2. plot
win.graph(7, 6); par(mfrow=c(2,1)); par(mar=c(3,4,4,2))
cont.exp(fx, -0.2, 1.2, prt=T, plot=TRUE)

# 3. E(Y), V(Y) 
cont.exp(fy, 1.2, 6.8, prt=T)

# 3. plot
cont.exp(fy, 1.2, 6.8, prt=T, plot=TRUE)

