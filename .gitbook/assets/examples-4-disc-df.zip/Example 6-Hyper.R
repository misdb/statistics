# Example 6-Hyper Geometric : Rstat Functions for HyperGeometric Distribution

library(Rstat)

# Number of Success(x), Number of Success Elements(S), 
# Number of Failure Elements (N-S), Sample Size (n)
N <- 50
S <- 10
n <- 10
x <- 0:n

# P(X=x) : dhyper() => prob. mass. function
fx1 <- dhyper(x, S, N-S, n)
plot(x, fx1)
disc.exp(x, fx1, plot=TRUE)

disc.cdf(x, fx1)

# P(X<=x) : phyper() => Cumulative Distribution Function
q <- x
fx2 <- phyper(q, S, N-S, n)
plot(q, fx2)   # the same as disc.cdf(x, fx1)

# P(X<=q) = p1 : qhyper() => find q (Quantile)

p1 <- 0:10 / 10
fx3 <- qhyper(p1, S, N-S, n, lower.tail=TRUE)
plot(p1, fx3)

# random number generator : rhyper()
# nn = number of random numbers
nn <- 100
fx4 <- rhyper(nn, S, N-S, n)
plot(table(fx4))



