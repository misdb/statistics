# Example 6-Pois : Rstat Functions for Poisson Distribution

library(Rstat)

# mean per unit time (lambda) (= n * p)
lamb <- 5

# P(X=x) : dpois() => prob. mass. function
x <- 0: 20
fx1 <- dpois(x, lamb)
plot(x, fx1)
disc.exp(x, fx1, plot=TRUE)

disc.cdf(x, fx1)

# P(X<=x) : ppois() => Cumulative Distribution Function
q <- x
fx2 <- ppois(q, lamb)
plot(q, fx2)   # the same as disc.cdf(x, fx1)

# P(X<=q) = p1 : qpois() =>  find q (Quantile)
p1 <- 0:10 / 10
fx3 <- qpois(p1, lamb, lower.tail=TRUE)
plot(p1, fx3)

# random number generator : rpois()
# nn = number of random numbers
nn <- 100
fx4 <- rpois(nn, lamb)
plot(table(fx4))



