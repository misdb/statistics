# Example 6-Binom : Rstat Functions for Binomial Distribution

library(Rstat)

# in case of (p = 0.2)
# number of trial(n), prob. of success(p), range of x
n <- 10; p <- 0.2; x <- 0:n

# P(X=x) : dbinom() => prob. mass. function
fx1 <- dbinom(x, n, p)
plot(x, fx1)

# P(X<=x) : pbinom() => Cumulative Distribution Function
q <- 1:10
fx2 <- pbinom(q, n, p)
plot(q, fx2)

# P(X<=q) = p1 : qbinom() => find q (Quantile)
p1 <- 0:10 / 10
fx3 <- qbinom(p1, n, p)
plot(p1, fx3)

# random number generator : rbinom()
# k = number of random numbers
k <- 100
fx4 <- rbinom(k, n, p)
plot(table(fx4))



