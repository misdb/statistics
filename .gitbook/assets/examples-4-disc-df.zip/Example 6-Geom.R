# Example 6-Geom : Rstat Functions for Geometric Distribution

library(Rstat)

# prob. of success (p)
p <- 0.1

# P(X=x) : dgeom() => prob. mass. function
x <- 1:20
fx1 <- dgeom(x, p)
plot(x, fx1)
disc.exp(x, fx1, plot=TRUE)

disc.cdf(x, fx1)

# P(X<=x) : pgeom() => Cumulative Distribution Function
fx2 <- pgeom(x, p)
fx2
plot(x, fx2)   # the same as disc.cdf(x, fx1)

# P(X<=q) = p1 : qgeom() =>  find q (Quantile)
p1 <- 0:10 / 10
fx3 <- qgeom(p1, p, lower.tail=TRUE)
plot(p1, fx3)

# random number generator : rgeom()
# nn = number of random numbers
nn <- 100
fx4 <- rgeom(nn, p)
plot(table(fx4))



