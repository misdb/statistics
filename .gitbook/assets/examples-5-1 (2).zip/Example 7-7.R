# Example 7-7

library(Rstat)

# 1. probability density function and cumulative function of X
alp <- 2                      # alpha
th <- 1:4                     # theta
x <- 0:210/30
dcol <- c("red", "blue", "green2", "purple")

# graph of prob. density function
win.graph(9,5);   par(mfrow = c(1,2))
plot(x, dgamma(x, alp, scale=th[1]), type="l", lwd=2, col=dcol[1],
     main="p.d.f of Gamma Distribution", ylab="f(x)", xlab="(a)")
grid(col=3)

for (i in 2:4) lines(x, dgamma(x, alp, scale=th[i]), lwd=2, col=dcol[i])

text(1.5, dgamma(1.5, alp, scale=th), labels=expression(theta))
text(1.5, dgamma(1.5, alp, scale=th), labels=paste0("=", th), pos=4)

# Cumulative distribution 
plot(x, pgamma(x, alp, scale=th[1]), type="l", lwd=2, col=dcol[1],
     main="Cumulative Distribution of Gamma Distribution", ylim=c(0, 1),
     ylab="F(x)", xlab="(b)")
grid(col=3)

for (i in 2:4) lines(x, pgamma(x, alp, scale=th[i]), lwd=2, col=dcol[i])

text(3.5, pgamma(3.5, alp, scale=th), labels=expression(theta))
text(3.49, pgamma(3.5, alp, scale=th), labels=paste0("=", th), pos=4)

