# Example 7-3

library(Rstat)

# 1. probability density function and cumulative function of X
theta <- 10
lamb <- 1/theta                                 # value of lambda

# Conditional Prob. (lower=FALSE) : P(X>5+3|X>5)
a <- 5; b <- 3
Pab <- pexp(a+b, lamb, lower=FALSE)
Pa <- pexp(a, lamb, lower=F)

Pab/Pa

# check the memoryless
pexp(3, lamb, lower=F)
