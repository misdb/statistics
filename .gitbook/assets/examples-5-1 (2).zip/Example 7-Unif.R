# Example 7-Uniform : Rstat Functions for Continuous Uniform Distribution

library(Rstat)

# 1. Probability Density Function of X
fx <- function(x) dunif(x, 0, 1)

# 2. P(ll<X<ul) : dunif()
# lower-limit(ll), upper-limit(ul)
ll <- 0
ul <- 1
cont.exp(fx, ll, ul, prt=TRUE, plot=TRUE)
 
# 3. P(X<=x) : punif() => Cumulative Distribution Function
x <- (0:10)/10
fx2 <- punif(x, ll, ul, lower.tail=TRUE)
plot(x, fx2)
cont.cdf(fx, ll, ul, xs=x)

# 4. P(X<=q) = p1 : qunif() => find q (Quantile)
p1 <- 0:10 / 10
fx3 <- qunif(p1, ll, ul, lower.tail=TRUE)
plot(p1, fx3)

# 5. random number generator : runif()
# k = number of random numbers
k <- 1000
fx4 <- runif(k, min=ll, max=ul)
hist(fx4, breaks=10)



