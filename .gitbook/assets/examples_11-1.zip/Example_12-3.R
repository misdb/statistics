# Example 12-3

library(Rstat)


#--------------------------------
# Method #1

# observed data
v <- c(6, 6, 2, 2, 3,  5, 2, 6, 1, 3,  2, 1, 3, 9, 6,  3, 0, 3, 2, 2,
       2, 4, 4, 4, 4,  1, 4, 2, 4, 4,  4, 4, 4, 2, 7,  6, 7, 4, 7, 3,
       3, 8, 1, 5, 3,  8, 7, 4, 2, 6,  2, 6, 4, 4, 4,  2, 5, 2, 2, 7,
       4, 4, 5, 4, 2,  7, 7, 4, 3, 4,  4, 6, 3, 3, 3,  3, 4, 2, 2, 7)

# Table of data
n <- length(v)
x <- table(v); x

# conversion of data type
y <- as.numeric(names(x)); y
x <- as.numeric(x); x

# computing the probability and Expected Frequency
py <- dpois(y, 4)
npy <- n*py; npy

# merge the ranges which has less than 5 expected frequency.
p <- c(py[1]+py[2], py[3:7], 1-sum(py[1:7]))
np <- n*p; np
x <- c(x[1]+x[2], x[3:7], sum(x[8:10])); x


# goodness of fit test
ct <- chisq.test(x, p=p); ct     # (Result) p-value is greater than alpha... Accept Null Hypohesis.

# Plot the result

# test statistic, rejection value
tst <- ct$stat
rej <- qchisq(0.95, length(x)-1)   # (or) rej <- qchisq(0.95, ct$para)

win.graph(7, 5)
chitest.plot(stat=tst, df=ct$para, side="up", ppt=100)

# Display the rejection value
segments(rej, -0, rej, dchisq(rej, ct$para), lwd=2, col=2)
# text(rej, 0, labels=round(rej, 4), pos=1, col=4)
text(tst, dchisq(tst, length(x)-1), labels=expression(chi[0]^2), pos=3, col=2, cex=1.2)
text(rej, dchisq(rej, length(x)-1)*2, labels=expression(chi['0.95:;6']^2), pos=3, col=2, cex=1.2)

#--------------------------------
# Method #2

# data import from Rstat package
data(exa12_3)

x <- table(exa12_3); x
n <- length(exa12_3); n

# conversion of data type
y <- as.numeric(names(x)); y
x <- as.numeric(x); x

# computing the probability and Expected Frequency
py <- dpois(y, 4)
npy <- n*py; npy

# merge the ranges which has less than 5 expected frequency.
p <- c(py[1]+py[2], py[3:7], 1-sum(py[1:7])); p
np <- n*p; np
x <- c(x[1]+x[2], x[3:7], sum(x[8:10])); x

# goodness of fit test
ct <- chisq.test(x, p=p); ct     # (Result) p-value is greater than alpha... Accept Null Hypohesis.

# Plot the result
chitest.plot2(stat=ct$stat, df=ct$para, side="up", ppt=100)

