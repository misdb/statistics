# Example 12-2

library(Rstat)

# observed frequency
x <- c(32, 65, 47, 38, 18)   
p <- c(0.15, 0.3, 0.25, 0.2, 0.1)     

# goodness of fit test
ct <- chisq.test(x, p=p); ct     # (Result) p-value is greater than alpha... Accept Null Hypohesis.

#--------------------------------
# Method #1

# Plot the result

# test statistic, rejection value
tst <- ct$stat
rej <- qchisq(0.95, length(x)-1)

win.graph(7, 5)
chitest.plot(stat=tst, df=ct$para, side="up", ppt=100)

# Display the rejection value
segments(rej, -0, rej, dchisq(rej, ct$para), lwd=2, col=2)
text(rej, 0, labels=round(rej, 4), pos=1, col=4)
text(tst, dchisq(tst, 4), labels=expression(chi[0]^2), pos=3, col=2, cex=1.2)
text(rej, dchisq(rej, 4), labels=expression(chi['0.95:;4']^2), pos=3, col=2, cex=1.2)

#--------------------------------
# Method #2
chitest.plot2(stat=ct$stat, df=ct$para, side="up", ppt=100)

