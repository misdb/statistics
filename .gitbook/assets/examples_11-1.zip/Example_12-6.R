# Example 12-6

library(Rstat)


#--------------------------------
# Method #1

# observed data
x <- c(20, 16, 29, 21, 14,   14, 22, 26, 25, 13,
       18, 24, 32, 18, 8,     8, 18, 33, 16, 25)

# x as matrix
x <- matrix(x, nrow=4, ncol=5, byrow=TRUE); x

# delete the 4th row
x2 <- x[-4, ]; x2

# test of homogeneity
ct <- chisq.test(x2); ct     # (Result) p-value is greater than alpha, so Accept NULL hypothesis.

# Plot the result

# test statistic, rejection value
deg <- ct$para
tst <- ct$stat
rej <- qchisq(0.95, deg) ; rej

win.graph(7, 5)
chitest.plot(stat=tst, df=deg, side="up")

# Display the rejection value
segments(rej, 0, rej, dchisq(rej, deg)*2, lty=2, col=4)
text(rej, 0, labels=round(rej, 4), pos=1, col=4)
text(tst, dchisq(tst, deg)*.7, labels=expression(chi[0]^2), pos=3, col=2, cex=1.2)
text(rej, dchisq(rej, deg)*2, labels=expression(chi['0.95;8']^2), pos=3, col=4, cex=1.2)

#--------------------------------
# Method #2

# data import from Rstat package
data(exa12_5)

x2 <- exa12_5[-4, ]; x2

# goodness of fit test
ct <- chisq.test(x2); ct     # (Result) p-value is greater than alpha, so Accept NULL hypothesis.

# Calculate the p-value again    # (Result) p-value 
chitest.plot2(stat=ct$stat, df=ct$para, side="up")

