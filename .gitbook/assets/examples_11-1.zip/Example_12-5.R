# Example 12-5

library(Rstat)


#--------------------------------
# Method #1

# observed data
x <- c(20, 16, 29, 21, 14,   14, 22, 26, 25, 13,
       18, 24, 32, 18, 8,     8, 18, 33, 16, 25)

# x as matrix
x <- matrix(x, nrow=4, ncol=5, byrow=TRUE); x


# test of homogeneity
ct <- chisq.test(x); ct     # (Result) p-value is less than alpha, so reject NULL hypothesis.

# Plot the result

# test statistic, rejection value
deg <- ct$para
tst <- ct$stat
rej <- qchisq(0.95, deg) ; rej

win.graph(7, 5)
chitest.plot(stat=tst, df=deg, side="up")

# Display the rejection value
segments(rej, 0, rej, dchisq(rej, deg)*2, lty=2, col=4)
# text(rej, 0, labels=round(rej, 4), pos=1, col=4)
text(tst, dchisq(tst, deg), labels=expression(chi[0]^2), pos=3, col=2, cex=1.2)
text(rej, dchisq(rej, deg)*2, labels=expression(chi['0.95;12']^2), pos=3, col=4, cex=1.2)

#--------------------------------
# Method #2

# data import from Rstat package
data(exa12_5)

# goodness of fit test
ct <- chisq.test(exa12_5); ct     # (Result) p-value is less than alpha, so reject NULL hypothesis.

# Calculate the p-value again    # (Result) p-value 
chitest.plot2(stat=ct$stat, df=ct$para, side="up")

