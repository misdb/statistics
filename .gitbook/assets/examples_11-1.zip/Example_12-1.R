# Example 12-1

library(Rstat)

# observed frequency
x <- c(31, 26, 22, 18, 13, 10)        

# goodness of fit test
ct <- chisq.test(x); ct     # (Result) p-value is less than alpha... Reject Null Hypohesis.

#--------------------------------
# Method #1

# Plot the result

# test statistic, rejection value
tst <- ct$stat
rej <- qchisq(0.95, 5)

win.graph(7, 5)
chitest.plot(stat=tst, df=ct$para, side="up")

# Display the rejection value
segments(rej, -0, rej, dchisq(rej, ct$para), lwd=2, col=2)
text(rej, 0, labels=round(rej, 4), pos=1, col=4)
text(tst, dchisq(tst, 5), labels=expression(chi[0]^2), pos=3, col=2, cex=1.2)
text(rej, dchisq(rej, 5), labels=expression(chi['0.95:;5']^2), pos=3, col=2, cex=1.2)


#--------------------------------
# Method #2
chitest.plot2(stat=ct$stat, df=ct$para, side="up")

