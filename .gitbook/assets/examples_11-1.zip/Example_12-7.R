# Example 12-7

library(Rstat)


#--------------------------------
# Method #1

# observed data
x <- c( 39, 18, 12, 31, 14,   35, 23, 18, 35, 13,
        27, 16, 17, 24, 8,     9, 12, 8, 19, 22)

# x as matrix
x <- matrix(x, nrow=4, ncol=5, byrow=TRUE); x

# test of independence
ct <- chisq.test(x); ct     # (Result) p-value is less than alpha, so Reject NULL hypothesis.

# Plot the result : Mosaic Plot
subject <- c("Kor", "Eng", "Math", "etc.")
hope <- c("Sam", "Pub", "Exp", "Sal", "etc.")

# table of matrix
t1 <- as.table(x)
dimnames(t1) <- list(subject=subject, hope=hope)

# Install package 'vcd' for Mosaic plot
install.packages("vcd")
library(vcd)

mosaic(t1, shade=T, pop=F, main="Favorite Subjects and Hopes of Students",
       labeling_args=list(offset_varnames=c(top=1), offset_labels=c(top=0.3)))

labeling_cells(text=round(chisq.test(t1)$res, 1), clip=FALSE)(t1)

#--------------------------------
# Method #2

# data import from Rstat package
data(exa12_7); x <- exa12_7

# test of independence
ct <- chisq.test(x); ct     # (Result) p-value is less than alpha, so Reject NULL hypothesis.

# Plot the result
# Calculate the p-value  
chitest.plot2(stat=ct$stat, df=ct$para, side="up", pup=0.9995)

# Plot the result : Mosaic Plot
subject <- c("Kor", "Eng", "Math", "etc.")
hope <- c("Sam", "Pub", "Exp", "Sal", "etc.")

# table of matrix
t1 <- as.table(x)
dimnames(t1) <- list(subject=subject, hope=hope)

# Install package 'vcd' for Mosaic plot
# install.packages("vcd")
library(vcd)

win.graph(7,6)
mosaic2(tab=t1, mt="Favorite Subjects and Hopes of Students")
