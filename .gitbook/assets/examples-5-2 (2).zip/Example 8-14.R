# Example 8-14

# X-axis, degree of freedom
nu <- c(5, 10, 30, 100)
p <- (1:99)/100

# Graph Window 2*2
par(mfrow=c(2,2))  

# Quantile/E(X)
for (i in 1:length(nu)) {
    plot(p, qchisq(p, nu[i])/nu[i], type="l",
         main=paste0("Chi-Sq(", nu[i], ")"),
         lwd=2, col=2, ylab="x(p)", ylim=c(0, 3))
    abline(h=1)
    abline(v=c(0.025, 0.05, 0.5, 0.95, 0.975), lty=2, col=4)}