# Example 8-2

library(Rstat)

# 1. compute the cumulative probability
pnorm(1)
pnorm(-1.5)

# 2. setting parameters and ranges for computing the probability
mu <- 2; sig <- 2; a <- -1; b <- 4

# 3. function 'norm.trans()'
norm.trans(mu, sig, a, b)