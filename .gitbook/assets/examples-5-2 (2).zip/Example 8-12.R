# Example 8-12

library(Rstat)

# df and x-axis point
nu <- c(5, 10, 30, 100)
up <- qchisq(0.99, max(nu))

# cont.spdf()
cont.spdf("chi", 0, up, para=nu, xp=nu)


