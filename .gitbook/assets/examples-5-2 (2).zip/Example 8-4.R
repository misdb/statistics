# Example 8-4

library(Rstat)

# point of computing quantile using cumulative prob.
pv <- c(0.005, 0.01, 0.025, 0.05, 1:9/10, 0.95, 0.975, 0.99, 0.995)

# quantile of standard normal distribution : function 'snorm.quant()'
snorm.quant(pv, pv)


# 
zv <- qnorm(pv)
names(zv) <- pv
print(round(zv, 4))

# quantiles
p <- 1:199/200
plot(p, qnorm(p), type="l", lwd=2, col=2, ylim=c(-3, 2.6), xlim=c(-0.1, 1), 
     main = "Quantiles : Standard Normal Distribution")
abline(v=0.5, h=0, lty=3, col=2)

# print quantiles on the graph
segments(pv, -2.7, pv, zv, lty=2, col=4)
segments(pv, zv, 0, zv, lty=2, col=4)
text(-0.07, zv, labels=format(zv, digits=3))
text(pv[-c(2:4, 14:16)], -3, labels=pv[-c(2:4, 14:16)])

