# Example 8-2

library(Rstat)

# X-axis ( -7 ~ 7)
x <- (-140:140)/20

# parameter, prob. area of normal distribution
mu <- 2; sig <- 2; a <- -1; b <- 4

# Calculation of prob. density
fx <- matrix(c(dnorm(x,0,1), dnorm(x, mu, sig)), ncol=2, byrow=F)

# Calculation of Prob.
px <- pnorm(4, mu, sig) - pnorm(-1, mu, sig); px

c <- (a-mu)/sig; d <- (b-mu)/sig
pz <- pnorm(d) - pnorm(c); pz

# Drwa the Graphs
win.graph(8,6); par(mfrow=c(2,1)); par(mar=c(3,4,3,1))
plot(x, fx[,2], type="n", main="N(2,4)", ylim=c(0, 0.4), ylab="f(x)")
cord.x <- c(a, seq(a, b, 0.01), b)
cord.y <- c(0, dnorm(seq(a, b, 0.01), mu, sig), 0)

# Draw Polygon
polygon(cord.x, cord.y, col='lightcyan')
text(1.5, 0.05, labels=paste0("P(", a, "<X<", b, ")\n=", round(px, 4)))
lines(x, fx[,2], lwd=2, col=2)

# Standard Normal Distribution
plot(x, fx[,1], type="n", main="N(0,1)", ylim=c(0, 0.4), ylab="f(x)")
cord.x <- c(c, seq(c, d, 0.01), d)
cord.y <- c(0, dnorm(seq(c, d, 0.01)), 0)
polygon(cord.x, cord.y, col='lightcyan')
text(-0.25, 0.1, labels=paste0("P(", c, "<Z<", d, ")\n=", round(pz, 4)))
lines(x, fx[,1], lwd=2, col=2)


#---------------------
# norm.trans()
#---------------------

# 1. compute the cumulative probability
pnorm(1)
pnorm(-1.5)

# 2. setting parameters and ranges for computing the probability
mu <- 2; sig <- 2; a <- -1; b <- 4

# 3. function 'norm.trans()'
norm.trans(mu, sig, a, b)