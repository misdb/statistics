# Example 8-5

library(Rstat)

# Using Standardization
pnorm(1.25)
pnorm(0.625)
pnorm(1.25)-pnorm(0.625)


# Direct Computation
pnorm(185, 175, 8)-pnorm(180, 175, 8)


