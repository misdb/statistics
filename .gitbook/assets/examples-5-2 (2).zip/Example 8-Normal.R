# Example 8-Normal : Rstat Functions for Normal Distribution

library(Rstat)

# 1. Probability Density Function of X : dnorm()
mu <- 0
sd <- 1
x <- seq(-3, 3, length=200)
plot(x, dnorm(x, mean=mu, sd=sd), type='l', main="Normal distribution, X~N(0,1)") 

cont.spdf("norm", -3, 3, mu, sd, xp=mu)

# 2. P(X<=q) : pnorm() => Cumulative Distribution Function
# P(X<-1.5), P(X<1)
q <- c(-1.5, 1)
pnorm(q)

norm.trans(mu=mu, sig=sd, -3, -1.5)
norm.trans(mu=mu, sig=sd, -3, 1)

zp <- seq(-3, 3, by=0.5)
snorm.cdf(zp)

# 3. P(-1.5<X<1) = P(X<1) - P(X<-1.5)
pnorm(1) - pnorm(-1.5)

norm.trans(mu=mu, sig=sd, -1.5, 1)

# 4. P(X<=q) = p1 : qexp() => find q (Quantile)
p1 <- c(0.01, 0.05, 0.10, 0.90, 0.95, 0.99)
fx3 <- pnorm(q=p1, mean=mu, sd=sd)
plot(p1, fx3)

# 5. random number generator : rexp()
# k = number of random numbers
k <- 1000
fx4 <- rnorm(k, mean=mu, sd=sd)
hist(fx4, breaks=20)




