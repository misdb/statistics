# Example 8-11

# Table of Chi-square Distribution

# Cumulative Probability
p <- c(0.005, 0.01, 0.025, 0.05, 0.1, 0.9, 0.95, 0.975, 0.09, 0.995)
nc <- length(p)

# degree of freedom
df <- c(1:40, 50, 100)
nr <- length(df)

# making quantile
qv <- array(0, dim=c(nr, nc))
colnames(qv) <- p; rownames(qv) <- df

for (i in 1:nc) qv[,i] <- qchisq(p[i], df)
print(round(qv, 3))
