# Example 8-1

library(Rstat)

# X-axis
x <- (-140:140) / 20

# Normal Distribution
fx <- matrix(c(dnorm(x, 0, 1), dnorm(x, 0, 2), dnorm(x, 2, 1), dnorm(x, 2, 2)),
      ncol=4, byrow=F)

# Draw the Graphs
win.graph(7, 6); par(mfrow=c(2,2))

plot(x, fx[,1], main="N(0,1)", type="l", lwd=2, col=2, ylab="f(x)", xlab="(a)")

# Draw segments
segments(0,0,0, max(fx[,1]), lty=2, col=4)

plot(x, fx[,2], main="N(0,4)", type="l", lwd=2, col=2, ylab="f(x)", xlab="(b)")
segments(0,0,0, max(fx[,2]), lty=2, col=4)

plot(x, fx[,3], main="N(2,1)", type="l", lwd=2, col=2, ylab="f(x)", xlab="(c)")
segments(2,0,2, max(fx[,3]), lty=2, col=4)

plot(x, fx[,4], main="N(2,4)", type="l", lwd=2, col=2, ylab="f(x)", xlab="(d)")
segments(2,0,2, max(fx[,4]), lty=2, col=4)



#-------------------
# cont.spdf()
#-------------------

# parameters of Normal Distribution : function 'cont.spdf()'
mu <- c(0, 0, 2, 2)
sig <- c(1, 2, 1, 2)

cont.spdf("norm", -7, 7, mu, sig, xp=mu)