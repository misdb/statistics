# Example 8-16

# Table of t-Dist Quantile

# a
a <- c(5:9/10, 0.95, 0.975, 0.09, 0.995)
nc <- length(a)

# degree of freedom
df <- c(1:40, 50, 100, Inf)
nr <- length(df)

# making quantile
qv <- array(0, dim=c(nr, nc))
colnames(qv) <- a; rownames(qv) <- df

for (i in 1:nc) qv[,i] <- qt(a[i], df)
print(round(qv, 3))
