# Example 9-7

library(Rstat)

n <- 10               # sample size
m <- 100              # mean
si <- 10              # standard deviation

# simulation function : 'tdist.sim()'
chi.sim(ns=n, mu=m, sig=si, muknow=FALSE)

#**** degree of freedom = (n-1) rather than (n) ****
