# Example 9-8

library(Rstat)

# degree of freedom, cumulative function
n <- c(5, 10, 30, 100)  # sample size
p <- 0.95

# quantile / df (constant c)
qchisq(p, n-1) / (n-1)
