# Example 9-2

library(Rstat)

n <- 16; se = 5 /sqrt(n)

# Method 1 : Calculation
pnorm(2, 0, se)

# Method 2 : Standardization
pnorm(2/se) - pnorm(-2/se)

# Method 3 : Symmmetry
2*pnorm(2/se) - 1


