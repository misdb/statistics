# Example 9-2

library(Rstat)

n <- 16; se = 5 /sqrt(n)

# P( -2 <= X - mu <= 2)
# Method 1 : Calculation
(pnorm(2, 0, se) - 0.5) * 2

# Method 2 : Standardization
pnorm(2/se) - pnorm(-2/se)

# Method 3 : Symmmetry
2*pnorm(2/se) - 1


