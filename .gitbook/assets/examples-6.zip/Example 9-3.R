# Example 9-3

library(Rstat)

# Method 1 : Calculation
ceiling((qnorm(0.975)/0.4)^2)

# Method 2 : Using user-defined function
# p : level of confidence, sigma : limit of erroe
findsn <- function(p, sigma) ceiling((qnorm(1-(1-p)/2)/sigma)^2)
findsn(0.95, 4:1/10)

findsn(95:99/100, 0.4)


