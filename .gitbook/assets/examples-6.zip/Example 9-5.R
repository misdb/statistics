# Example 9-5

library(Rstat)

n <- 10               # sample size
m <- 100              # mean
si <- 10              # standard deviation

# simulation function : 'tdist.sim()'
tdist.sim(ns=n, mu=m, sig=si)
