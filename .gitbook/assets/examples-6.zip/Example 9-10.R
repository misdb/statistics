# Example 9-10

library(Rstat)

# Method 1
qf(0.05, 11, 15, lower.tail=FALSE)

# Method 2
qf(0.95, 11, 15)


# The ratio of the two sample variance more than twice 
# = P(F<0.5) + P(F>2)
pf(0.5, 11, 15) + (1-pf(2, 11, 15))