# Example 9-1

library(Rstat)

norm.sim(ns=10, mu=100, sig=10, N=10000)



