# Example 9-4

library(Rstat)

# 3 levels of significance
alp <- c(0.01, 0.05, 0.1)
dcol <- c(2, 4, "green4")

# using function `norm.spn()`
norm.spn(kp=0.4, alp, dcol = dcol)

# in case of k=0.2 => sample size is increasing....
norm.spn(kp=0.2, alp, dcol = dcol)