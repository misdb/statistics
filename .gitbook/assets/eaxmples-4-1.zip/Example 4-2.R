# Example 4-2

library(Rstat)

# 1) Sample Space
S <- tosscoin2(3)

# 2) definition of function 'countT '
countT <- function(x) sum(x=="T")

# 3) definition of X
X <- apply(S, 1, countT)

# 4) prob. distribution of X
table(X)/nrow(S)