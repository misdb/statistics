# Example 4-7

library(Rstat)

# Probability distribution function of X 
pdf <- function(x) 2* exp(-2*x)*(x>0)

# function 'cont.cdf()' :
# cdf and Plot of Continuous Random Variable
cont.cdf(pdf, low=-1, up=3, xs=c((1:5)*0.2,2))
