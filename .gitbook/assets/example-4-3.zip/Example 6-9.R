# Example 6-9

# 1. Prob. Distribution of X
x <- 1:100
p <- 1/6

fx <- dgeom(x-1, p)

# 2. E(X), V(X)
disc.exp(x, fx)

# 3. 6 in 3 trials (x=3)
sum(dgeom(0:2, p))

# or using 'pgeom()' function
pgeom(2, p)


