# Example 13-1

library(Rstat)

#-------------------
#  Method #1

# Data
y <- c(79, 83, 88, 78, 75,   81, 89, 91, 84, 86, 82, 
       86, 91, 93, 90, 89,   76, 81, 82, 79)
f <- c(rep(150, 5), rep(200, 6), rep(250, 5), rep(300, 4))

# change levels into factors : as.factor()
af <- as.factor(f)
ym <- tapply(y, af, mean); ym

# pre-study of data
win.graph(7, 5)
boxplot(y ~ af, col=7, main="Rate by Temperature", 
        xlab="Temperature", ylab="Rate")
points(af, y, pch=19, col=2, cex=1.2)
lines(1:4, ym, type="b", lty=2, pch=17, col=4, cex=1.2)

# ANOVA
an1 <- aov(y ~ af)
ans1 <- summary(an1); ans1

# Diagnosis Graph
win.graph(7, 4); par(mfrow=c(1,2))
plot(an1, which=1:2)

#-------------------
#  Method #2

data(exa13_1)

y <- exa13_1[[1]]; f <- exa13_1[[2]]

# One-way ANOVA : anova1() of Rstat, step 0~3
anova1(y, f, xl="Temparature", yl="Rate", step=0:3)



