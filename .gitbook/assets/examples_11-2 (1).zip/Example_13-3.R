# Example 13-3

library(Rstat)

#-------------------
#  Method #1

# Data
y <- c(79, 83, 88, 78, 75,   81, 89, 91, 84, 86, 82, 
       86, 91, 93, 90, 89,   76, 81, 82, 79)
f <- c(rep(150, 5), rep(200, 6), rep(250, 5), rep(300, 4))

# change levels into factors : as.factor()
af <- as.factor(f)
ym <- tapply(y, af, mean); ym

# of repetition by levels
n1 <- tapply(y, af, length); n1

# ANOVA
an1 <- aov(y ~ af)
ans1 <- summary(an1); ans1

# MSE and width of CI(tol)
mse <- summary(an1)[[1]]$Mean[2]; mse

# Mean difference vector
ymv <- c(ym[1]-ym[-1], ym[2]-ym[-(1:2)], ym[3]-ym[-(1:3)])
lev <- c("A1", "A2", "A3", "A4")
names(ymv) <- c(paste0(lev[1], "-", lev[-1]), 
                paste0(lev[2], "-", lev[-(1:2)]),
                paste0(lev[3], "-", lev[-(1:3)]))

# CI Bands of Mean Difference
tol <- qt(0.975, 16) * sqrt(mse) * sqrt(c(1/n1[1] + 1/n1[-1],
                                          1/n1[2] + 1/n1[-(1:2)],
                                          1/n1[3] + 1/n1[-(1:3)]))
names(tol) <- names(ymv)

# C.I.
lcl <- ymv - tol; ucl <- ymv + tol; rbind(ymv, tol, lcl, ucl)
                
# Plot of CI
n <- length(ymv)
win.graph(7, 5)
plot(ymv, type="b", pch=17, lty=2, col=2, cex=1.2, xlim=c(0.5, n+0.5), 
     main="Population Mean Differenc CI of Rate by Level Combinations",
     ylab="Rate Difference", xlab="Level Combination", ylim=c(min(lcl)-3, max(ucl)))
grid(col=3)

# Lines of Responses Differences
abline(h=0, lty=2, col=grey(0.4))

# Draw the lines of upper limit and lower limit of Mean Differences by levels
lines(1:n, lcl, lty=4, col=4)
lines(1:n, ucl, lty=4, col=4)

# CI of Mean Differences by levels
arrows(1:n, lcl, 1:n, ucl, lwd=2, length=0.1, code=3, angle=90)

# upper limit and lower limit of Mean Differences by levels
text(1:n, min(lcl)-2, labels=names(ymv), col=4, cex=0.9)
text(1:n, ymv, labels=round(ymv, 2), cex=0.9, col=2, pos=4)
text(1:n, lcl, labels=round(lcl, 2), cex=0.9, col=1, pos=4)
text(1:n, ucl, labels=round(ucl, 2), cex=0.9, col=1, pos=4)


#-------------------
#  Method #2

data(exa13_1)

y <- exa13_1[[1]]; f <- exa13_1[[2]]

# One-way ANOVA : anova1() of Rstat, step 6~7
anova1(y, f, xl="Temparature", yl="Rate", step=6:7, alp=0.05, dig=4)



