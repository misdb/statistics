# Example 13-2

library(Rstat)

#-------------------
#  Method #1

# Data
y <- c(79, 83, 88, 78, 75,   81, 89, 91, 84, 86, 82, 
       86, 91, 93, 90, 89,   76, 81, 82, 79)
f <- c(rep(150, 5), rep(200, 6), rep(250, 5), rep(300, 4))

# change levels into factors : as.factor()
af <- as.factor(f)

# of repetition by levels
n1 <- tapply(y, af, length); n1

# ANOVA
an1 <- aov(y ~ af)
ans1 <- summary(an1); ans1

# MSE and width of CI(tol)
mse <- summary(an1)[[1]]$Mean[2]; mse

tol <- qt(0.975, 16) * sqrt(mse/n1); tol

# C.I.
lcl <- ym - tol; ucl <- ym + tol; rbind(lcl, ucl)

# Plot of CI
win.graph(7, 5)
lev <- c(150, 200, 250, 300)
plot(f, y, pch=19, col=3, cex=1.2, 
     main="Population Mean CI of Rate by Temperature",
     ylab="Rate", xlab="Temperature", xlim=c(125,325), ylim=c(75, 95))

# Draw the lines of mean, upper limit and lower limit by levels
lines(lev, ym, type="b", lty=2, pch=17, col=2, cex=1.2)
lines(lev, lcl, type="b", lty=4, pch=18, col=4, cex=1.2)
lines(lev, ucl, type="b", lty=4, pch=18, col=4, cex=1.2)

# CI of Responses by levels
arrows(lev, lcl, lev, ucl, lwd=2, length=0.1, code=3, angle=90)

# mena, upper limit and lower limit by levels
text(lev, ym, labels=ym, cex=0.9, col=2, pos=4)
text(lev, lcl, labels=round(lcl, 3), cex=0.9, col=4, pos=4)
text(lev, ucl, labels=round(ucl, 3), cex=0.9, col=4, pos=4)


#-------------------
#  Method #2

data(exa13_1)

y <- exa13_1[[1]]; f <- exa13_1[[2]]

# One-way ANOVA : anova1() of Rstat, step 4~5
anova1(y, f, xl="Temparature", yl="Rate", step=4:5, alp=0.05, dig=4)



