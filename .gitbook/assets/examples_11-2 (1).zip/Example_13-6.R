# Example 13-6

library(Rstat)

#-------------------
#  Method #1

# Data
rate <- c( 77.5, 80, 89, 80.5,   80, 85, 92.5, 84.5,   84, 88.5, 87, 76.5)
f1 <- rep(c(100, 150, 200, 250), 3)
f2 <- rep(1:3, each=4)

# change levels into factors : as.factor()
temp <- as.factor(f1)
pres <- as.factor(f2)

# Pre-study on Data => interaction.plot() function
win.graph(7,5)
interaction.plot(temp, pres, rate, col=c(1,2,4), lwd=2, 
                 ylab="Rate",
                 main="Interaction Effect of Temperature and Pressure on Rate")
grid(col=3)

# ANOVA
an2 <- aov(rate ~ temp + pres)
ans2 <- summary(an2); ans2

# Diagnosis Graph
win.graph(7,3.5); par(mfrow=c(1,2))
plot(an2, which=1:2)


#-------------------
#  Method #2
rm(list=ls()); data(exa13_6)
exa13_6
names(exa13_6) <- c("rate", "temp", "pres")

attach(exa13_6)

# change levels into factors : as.factor()
temp <- as.factor(temp)
pres <- as.factor(paste0(pres, "-Pressure"))

# Two-way ANOVA (No repetition) : anova2() of Rstat, step 0:3
anova2(rate, temp, pres, step=0:3, inter=FALSE)