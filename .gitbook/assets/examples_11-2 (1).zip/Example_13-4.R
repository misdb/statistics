# Example 13-4

library(Rstat)

#-------------------
#  Method #1

# Data
rate <- c( 76, 79, 81, 79, 83, 85,   79, 81, 84, 86, 89, 88,   87, 91, 91, 94, 88, 86,   
           79, 82, 85, 84, 77, 76 )
f1 <- c(rep(100, 6), rep(150, 6), rep(200, 6), rep(250, 6))
f2 <- rep(c(1,1,2,2,3,3), 4)

# change levels into factors : as.factor()
temp <- as.factor(f1)
pres <- as.factor(f2)

# Pre-study on Data => interaction.plot() function
win.graph(7,5)
interaction.plot(temp, pres, rate, col=c(1,2,4), lwd=2, 
                 ylab="Mean of Rate",
                 main="Interaction Effect of Temperature and Pressure on Rate")
grid(col=3)

# ANOVA
an2 <- aov(rate ~ temp * pres)
summary(an2);

# Diagnosis Graph
win.graph(7, 3.5); par(mfrow=c(1,2))
plot(an2, which=1:2)

#-------------------
#  Method #2

data(exa13_4); str(exa13_4)
names(exa13_4) <- c("rate", "temp", "pres")
attach(exa13_4)

# change levels into factors : as.factor()
temp <- as.factor(temp)
pres <- as.factor(paste0(pres, "-Pressure"))
levels(pres)

# Two-way ANOVA : anova2() of Rstat, step 0:3
# Interaction Effect Plot
anova2(rate, temp, pres, step=0:3)


