# Example 13-5

library(Rstat)

#-------------------
#  Method #1

# Data
rate <- c( 76, 79, 81, 79, 83, 85,   79, 81, 84, 86, 89, 88,   87, 91, 91, 94, 88, 86,   
           79, 82, 85, 84, 77, 76 )
f1 <- c(rep(100, 6), rep(150, 6), rep(200, 6), rep(250, 6))
f2 <- rep(c(1,1,2,2,3,3), 4)

# change levels into factors : as.factor()
temp <- as.factor(f1)
pres <- as.factor(f2)

# Pre-study on Data => interaction.plot() function
win.graph(7,5)
interaction.plot(temp, pres, rate, col=c(1,2,4), lwd=2, 
                 ylab="Mean of Rate",
                 main="Interaction Effect of Temperature and Pressure on Rate")
grid(col=3)

# Means by Level Combinations : tapply()
ym <- tapply(rate, list(pres, temp), mean); ym

# ANOVA
an2 <- aov(rate ~ temp * pres)
# summary(an2);

# MSE
mse <- summary(an2)[[1]]$Mean[4]; mse

# CI Bands
tol <- qt(0.975, 12) * sqrt(mse/2); tol

# CI of optimal levels
ymax <- max(ym)
lmax <- ymax - tol
umax <- ymax + tol
paste0("[", ymax, " +/- ", round(tol, 3), "]=[", round(lmax, 3), ", ", round(umax, 3), "]")

# CI of all levels
lcl <- ym - tol; lcl
ucl <- ym + tol; ucl

# CI Plot
win.graph(7,5)
plot(f1, rate, type="p", col=c(1,1,2,2,4,4), cex=1.2,
     main="95% CI of Rate Population Mean", ylim=c(min(lcl), max(ucl)),
     xlab="Temperature", ylab="Rate", xlim=c(75, 275))

uf1 <- unique(f1)

# Draw lines of Means by Level Combinations
lines(uf1 - 3, ym[1,], type="b", lty=2, pch=17, col=1, cex=1.2)
lines(uf1, ym[2,], type="b", lty=2, pch=17, col=2, cex=1.2)
lines(uf1 + 3, ym[3,], type="b", lty=2, pch=17, col=4, cex=1.2)

# Display C.I.s
arrows(uf1 - 3, lcl[1,], uf1 - 3, ucl[1,], col=1, lwd=2, code=3, angle=90, length=0.05)
arrows(uf1, lcl[2,], uf1, ucl[2,], col=2, lwd=2, code=3, angle=90, length=0.05)
arrows(uf1 + 3, lcl[3,], uf1 + 3, ucl[3,], col=4, lwd=2, code=3, angle=90, length=0.05)

# Legends
legend("topright", c("1-Pressure", "2-Pressure", "3-Pressure"), lwd=2, text.col=c(1,2,4), col=c(1,2,4))


#-------------------
#  Method #2

data(exa13_4); str(exa13_4)
names(exa13_4) <- c("rate", "temp", "pres")
attach(exa13_4)

# change levels into factors : as.factor()
temp <- as.factor(temp)
pres <- as.factor(paste0(pres, "-Pressure"))
levels(pres)

# Two-way ANOVA : anova2() of Rstat, step 4:5
# Interaction Effect Plot
anova2(rate, temp, pres, step=4:5)

# CI Comparison in the Optimal Level 4
anova2(rate, temp, pres, step=6:7)