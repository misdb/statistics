# Example 10-4

library(Rstat)

# function : 'pmean.ci()'
pmean.ci(xb=199.5, sig=5, n=50)

pmean.ci(xb=199.5, sig=5, n=50, alp=0.05)

pmean.ci(xb=199.5, sig=5, n=50, alp=0.05, dig=2)


