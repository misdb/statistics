# Example 10-5

library(Rstat)

# function : 'pmean.ci()'
xb <- 199.5
sig <- 5
n <- 50
alp <- 0.05

# definition of spn : sample size for error = 1, 2, 3
spn <- function(del, sig, alp) ceiling((qnorm(1-alp/2)*sig/del)^2)

spn(1.2, sig, alp)

spn(1:3, sig, alp)

