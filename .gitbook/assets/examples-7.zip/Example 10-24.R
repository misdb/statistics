# Example 10-24

library(Rstat)

# matrix of CI and parameter
ci <- matrix(0, nrow=100, ncol=3)
n <- 16; p <- 0.6; alp <- 0.05; ir <- 1:100
mu <- n*p; sig <- sqrt(n*p*(1-p))

# quantile of standard normal distribution
zv <- qnorm(1-alp/2)

# seed()
set.seed(9857)

# random number generation and computation of CI
for (i in ir) {
     x <- rbinom(n, 1, p)
     xm <- sum(x)
     xp <- xm/n; xv <- xp*(1-xp)/n
     lcl <- max(0, xp - zv*sqrt(xv))
     ucl <- min(1, xp + zv*sqrt(xv))
     ci[i, ] <- c(lcl, xp, ucl)
    }

# Graph of CI
win.graph(7, 4)
plot(ir, ci[,2], type="p", pch=19, cex=0.6, col=1, ylim=c(min(ci), max(ci)),
     main="Simulation of Proportion C.I.", ylab="Confidence Interval", xlab="Repetition")
abline(h=p, col=2)
arrows(ir, ci[, 1], ir, ci[ ,3], length=0.03, code=3, angle=90, lwd=1.2,
       col=ifelse((ci[ ,1] > p | ci[ ,3] < p), 2, 4) )

# Number of CI not including Population Proportion
sum(ci[ ,1] > p);
sum(ci[ ,3] < p)
