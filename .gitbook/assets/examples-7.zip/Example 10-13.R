# Example 10-13

library(Rstat)

n <- 200
x <- 15
alp <- 0.05

# function : 'prob.ci()'
prob.ci(n, x, alp, dig=6)

# binom.test() of stats package
binom.test(x, n)$conf[1:2]
