# Example 10-15

library(Rstat)

# function of determining the sample size
nsamp <- function(err, alp=0.05, ph=0.5) {
           n <- ceiling(qnorm(1-alp/2)^2 * ph*(1-ph) / err^2)}

# Draw Graphs
win.graph(9, 4)
par(mfrow=c(1,3))

# 1. incresing the sample size to decrease error
erv <- (10:100)/500
plot(erv, nsamp(erv, 0.05, 0.1), type="l", lwd=3, col=2,
     main="Sample Size by Error", xlab="Limit of Error", ylab="Sample Size")

# 2. sample size according to significance level
alpv <- (10:100)/1000
plot(alpv, nsamp(0.02, alpv, 0.1), type="l", lwd=3, col=2,
     main="Sample Size by alpha", xlab="Significance Level", ylab="Sample Size")

# 3. changing p
pv <- (1:99)/100
plot(pv, nsamp(0.02, 0.05, pv), type="l", lwd=3, col=2,
     main="Sample Size by p", xlab="Proportion", ylab="Sample Size")
abline(v=0.5, lty=2, col=4)




# sample size
err <- 0.02
alp <- 0.05
ph <- 15/200

nsample(err, alp, ph)

# p : unknown
nsample(err, alp)

