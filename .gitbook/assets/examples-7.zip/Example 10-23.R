# Example 10-23

library(Rstat)

# matrix of CI and parameter
ci <- matrix(0, nrow=100, ncol=3)
n <- 16; mu <- 10; sig <- 2; alp <- 0.05; ir <- 1:100

# chisquare quantile
cv1 <- qchisq(alp/2, n-1); cv2 <- qchisq(1-alp/2, n-1)

# seed()
set.seed(9857)

# random number generation and computation of CI
for (i in ir) {
     x <- rnorm(n, mu, sig)
     xm <- var(x)
     xss <- xm * (n-1)
     lcl <- xss / cv2
     ucl <- xss / cv1
     ci[i, ] <- c(lcl, xm, ucl)
    }


# Graph of CI
win.graph(7, 4)
plot(ir, ci[,2], type="p", pch=19, cex=0.6, col=1, ylim=c(min(ci), max(ci)),
     main="Simulation of Variance C.I.", ylab="Confidence Interval", xlab="Repetition")
abline(h=sig^2, col=2)
arrows(ir, ci[, 1], ir, ci[ ,3], length=0.03, code=3, angle=90, lwd=1.2,
       col=ifelse((ci[ ,1] > sig^2| ci[ ,3] < sig^2), 2, 4) )

# Number of CI not including Population Variance
sum(ci[ ,1] > sig^2);
sum(ci[ ,3] < sig^2)
