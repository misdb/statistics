# Example 10-22

library(Rstat)

# matrix of CI and parameter
ci <- matrix(0, nrow=100, ncol=3)
n <- 16; mu <- 10; sig <- 2; alp <- 0.05; ir <- 1:100

# t-value
tv <- qt(1-alp/2, n-1)

# seed()
set.seed(9857)

# random number generation and computation of CI
for (i in ir) {
     x <- rnorm(n, mu, sig)
     xm <- mean(x)
     xs <- sd(x)
     lcl <- xm - tv * xs/sqrt(n)
     ucl <- xm + tv * xs/sqrt(n)
     ci[i, ] <- c(lcl, xm, ucl)
    }


# Graph of CI
win.graph(7, 4)
plot(ir, ci[,2], type="p", pch=19, cex=0.6, col=1, ylim=c(min(ci), max(ci)),
     main="Simulation of mean C.I.", ylab="Confidence Interval", xlab="Repetition")
abline(h=mu, col=2)
arrows(ir, ci[, 1], ir, ci[ ,3], length=0.03, code=3, angle=90, lwd=1.2,
       col=ifelse((ci[ ,1] > mu | ci[ ,3] < mu), 2, 4) )


