# Example 10-14

library(Rstat)

# function of determining the sample size
nsample <- function(err, alp=0.05, ph=0.5) {
           n <- qnorm(1-alp/2)^2 * ph*(1-ph) / err^2
           cat("n >=", n, " ==> n >=", ceiling(n), "\n") }

# sample size
err <- 0.02
alp <- 0.05
ph <- 15/200

nsample(err, alp, ph)

# p : unknown
nsample(err, alp)

