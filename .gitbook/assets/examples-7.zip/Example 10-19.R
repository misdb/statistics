# Example 10-19

library(Rstat)

# Definition of Function for Variance C.I.
vci1 <- function(x, alp=0.05, dig=3) {
        n <- length(x)
        xss <- sum(x^2) - sum(x)^2/n
        xv <- var(x)
        cv1 <- qchisq(alp/2, n-1); cv2 <- qchisq(1-alp/2, n-1)
        cat("[", round(xss/cv2, dig), ",", round(xss/cv1, dig), "]\n")
        return(list(var=xv, clev=100*(1-alp), conf=xss/c(cv2, cv1))) }

# Using function
x <- c(20.0, 21.5, 20.9, 19.8, 22.5, 20.3, 23.6, 18.0, 23.3, 17.8)
vcx <- vci1(x)

vcx <- vci1(x, dig=5)

vcx
