# Example 10-8

library(Rstat)

# function : 'pmean.ci2()'
pmean.ci2(xb=199.5, sig=5, n=16)

pmean.ci2(xb=199.5, sig=5, n=16, alp=0.05)

pmean.ci2(xb=199.5, sig=5, n=16, alp=0.05, dig=2)


