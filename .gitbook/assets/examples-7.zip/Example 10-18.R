# Example 10-18

library(Rstat)

# x-axis
x <- 0:250/10

# Drwa a graph
win.graph(7,5)
plot(x, dchisq(x, 10), type="l", lwd=2,
     main="pdf of Chi-Square(df=10)", ylab="f(x)")

p <- c(0.025, 0.05, 0.1, 0.5, 0.9, 0.95, 0.975)
lp <- length(p)
cp <- qchisq(p, 10)
round(cp, 3)

for (i in 1:lp) segments(cp[i], 0, cp[i], dchisq(cp[i], 10), lty=2, col=2)
abline(h=0)
text(cp, dchisq(cp, 10), labels=paste0("p=", p, "\n", round(cp, 3)), cex=0.8, col=4)
