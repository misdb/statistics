# Example 10-9

library(Rstat)

# data set : 'exa10_9' of 'Rstat'
data(exa10_9);
x <- exa10_9

# [ Method 1 ]
# Confidence Interval : pmean.ci2()
pmean.ci2(x, dig=3)                  # using data set directly


# [ Method 2 ]
# mean and sd of exa10_9
xb <- mean(x)
sig <- sd(x)

# Confidence Interval : pmean.ci2()
pmean.ci2(xb, sig, n=50, alp=0.05, dig=3)
