# Example 3-9

library(Rstat)

# Sample Space
S <- rolldie2(4);
S

# (1,2,3,4) (2,3,4,5) (3,4,5,6)  ??
is.cont <- function(x) all(diff(sort(x))==1)

A <- subset(S, apply(S, 1, is.cont)); element(A, 4)
pprt(A, nrow(S))