# Example 3-19
library(Rstat)

# Calculation of Posterior Probability
prior <- c(0.2, 0.4, 0.3, 0.1)
cond <- c(0.04, 0.02, 0.01, 0.05)

tot <- prior * cond; tot

sum_tot <- sum(tot); sum_tot

post <- tot/sum_tot; post

# Plot the result
bayes.plot(prior, post)