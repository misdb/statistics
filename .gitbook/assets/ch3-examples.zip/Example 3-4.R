# Example 3-4
library(Rstat)

# Sample Space
S1 <- rolldie2(2); element(S1)
 
S <- subset(S1, X1<=X2); element(S)

# 1. Event A
A <- subset(S, X2-X1 >=3); element(A)

# 2. Event B
B <- subset(S, X2 * X1 >= 20); element(B)

# 3. Intersection of A and B
AB <- intersect2(A,B); AB