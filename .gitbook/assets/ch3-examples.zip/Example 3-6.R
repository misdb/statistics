# Example 3-6

library(Rstat)

# 1. Sample Space and Number of Outcoms
S <- tosscoin2(4) 
S

S <- S[order(S$X1,S$X2,S$X3,S$X4),]
element(S, 4)

# 2. 
counth <- function(x) sum(x=="H")  # Count the number of "H"
A <- subset(S, apply(S, 1, counth) >= 2); element(A, 3)
pprt(A, nrow(S))