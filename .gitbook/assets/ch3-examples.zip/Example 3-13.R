# Example 3-13
library(Rstat)

# Make cards
card <- rep(c("C","D","H","S"), each=13)

# Sample space
card_4 <- urnsample2(card, size=4)
N <- nrow(card_4); N

# same shape cards
sameshape <- function(x) length(unique(x)) == 1
flush <- subset(card_4, apply(card_4, 1, sameshape))

# result
pprt(flush, N)

