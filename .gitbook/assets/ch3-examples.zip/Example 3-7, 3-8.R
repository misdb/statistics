# Example 3-7, 3-8
library(Rstat)

# Sample Space
S <- rolldie2(4);
S

# 1. Event A
A <- subset(S, apply(S, 1, sum) >= 15); element(A, 4)
pprt(A, nrow(S))

# 2. 
B <- subset(S, apply(S, 1, max) == 6); element(B, 4)
pprt(B, nrow(S))

# 3. 
C <- subset(S, apply(S, 1, min) == 1); element(C, 4)
pprt(C, nrow(S))

# 4. P(AB)
AB <- intersect2(A,B); element(AB)
pprt(AB, nrow(S))

# 5. P(AC)
AC <- intersect2(A,C); element(AC)
pprt(AC, nrow(S))

#6. P(BC)
BC <- intersect2(B,C); element(BC)
pprt(BC, nrow(S))

# 7. P(ABC)
ABC <- intersect2(AB,C); element(ABC)
pprt(ABC, nrow(S))

# 8. P(AuB), P(AuC), P(BuC), P(AuBuC)
AuB <- union2(A,B); element(AuB, 4)
AuC <- union2(A,C); element(AuC, 4)
BuC <- union2(B,C); element(BuC, 4)
AuBuC <- union2(AuB, C); element(AuBuC, 4)

pprt(AuB, nrow(S))
pprt(AuC, nrow(S))
pprt(BuC, nrow(S))
pprt(AuBuC, nrow(S))