# Example 3-2

library(Rstat)

# Sample Space
S1 <- rolldie2(2); element(S1)
 
S <- subset(S1, X1<=X2); element(S)

# 1. Event A
A <- subset(S, (X1+X2) %% 2 == 0); element(A)

# 2. Event B
B <- subset(S, (X1+X2) >= 8); element(B)

# 3. Event C
C <- subset(S, abs(X1-X2) <= 1); element(C)

# 4. Intersect of A and B
AB <- intersect2(A,B); element(AB)

# 5. Intersect of A and C
AC <- intersect2(A,C); element(AC)

# 6. Intersect of B and C
BC <- intersect2(B,C); element(BC)

# 7. Intersect of A and B and C
ABC <- intersect2(AB,C); element(ABC)

# 8. B Complement
Bc <- setdiff2(S, B); element(Bc)

# 9. Intersect of A and B Complement
ABc <- intersect2(A,Bc); element(ABc)

