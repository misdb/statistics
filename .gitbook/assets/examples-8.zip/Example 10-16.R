# Example 10-16

library(Rstat)

# Using 'bntest.plot()' of Rstat Package
# x = 2 : number of fault
bntest.plot(x=2, n=10, p0=0.1, side="up")

# x= c(3, 4)
bntest.plot(x=3:4, n=10, p0=0.1, side="up")

# x = c(2, 3, 4)
bntest.plot(x=2:4, n=10, p0=0.1, side="up")

