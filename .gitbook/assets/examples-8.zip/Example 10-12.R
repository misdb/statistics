# Example 10-12

library(Rstat)

# Data Set of Rstat : exa10_9
x <- exa10_9

# [ Method 1 ] Using function 't.test()' of base Package
To <- t.test(x, mu=200); 
To$stat[[1]]; To$p.val

# [ Method 2 ] Using 'meantest2.plot()' of Rstat Package
meantest2.plot(x, mu=200, side="two")

# Confidence Interval
To$conf[1:2]


# Critical Value of T : Tc
Tc <- qt(0.05/2, n-1, lower.tail=FALSE); Tc

#--------------------------------------------
# Decision Rule usign Critical Value
#--------------------------------------------
# (Right Tail Test)
#--------------------------------------------
# If To > Tc : reject Ho
#    otherwise accept Ho
#--------------------------------------------
# (Left Tail Test)
#--------------------------------------------
# If To < -Tc : reject Ho
#    otherwise accept Ho
#--------------------------------------------
# (Double-Sided Test)
#--------------------------------------------
# If To < -Tc or To > Tc : reject Ho
#    otherwise accept Ho
#--------------------------------------------

#--------------------------------------------
# Decision Rule using P-value  (Very Simple)
#--------------------------------------------
# if p-value < alpha : reject Ho
#    otherwise accept Ho