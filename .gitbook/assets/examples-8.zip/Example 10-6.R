# Example 10-6

library(Rstat)

# meantest1.plot()
xb <- 12.64
mu0 <- 12.5
sig <- 0.5
n <- 40
side <- "up"   # right-tail : "up", left-tail : "low", Double-Side : "two"

meantest1.plot(xb, mu0, sig, n, side=side)


# Critical Value of Z : Zc
qv <- qnorm(0.05, 12.5, 0.5, lower.tail=FALSE)
Zc <- (qv - mu0) / sig; Zc

#--------------------------------------------
# Decision Rule usign Critical Value
#--------------------------------------------
# (Right Tail Test)
#--------------------------------------------
# If Zo > Zc : reject Ho
#    otherwise accept Ho
#--------------------------------------------
# (Left Tail Test)
#--------------------------------------------
# If Zo < -Zc : reject Ho
#    otherwise accept Ho
#--------------------------------------------
# (Double-Sided Test)
#--------------------------------------------
# If Zo < -Zc or Zo > Zc : reject Ho
#    otherwise accept Ho
#--------------------------------------------

#--------------------------------------------
# Decision Rule using P-value  (Very Simple)
#--------------------------------------------
# if p-value < alpha : reject Ho
#    otherwise accept Ho