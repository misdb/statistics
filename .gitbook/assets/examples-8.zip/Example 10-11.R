# Example 10-11

library(Rstat)

# meantest2.plot() : population variance unknown
xb <- 199.5
mu0 <- 200
sig <- 1.8
n <- 50
side <- "two"   # right-tail : "up", left-tail : "low", Double-Side : "two"

meantest2.plot(xb, mu0, sig, n, side=side)

# Critical Value of T : Tc
Tc <- qt(0.05/2, n-1, lower.tail=FALSE); Tc

#--------------------------------------------
# Decision Rule usign Critical Value
#--------------------------------------------
# (Right Tail Test)
#--------------------------------------------
# If To > Tc : reject Ho
#    otherwise accept Ho
#--------------------------------------------
# (Left Tail Test)
#--------------------------------------------
# If To < -Tc : reject Ho
#    otherwise accept Ho
#--------------------------------------------
# (Double-Sided Test)
#--------------------------------------------
# If To < -Tc or To > Tc : reject Ho
#    otherwise accept Ho
#--------------------------------------------

#--------------------------------------------
# Decision Rule using P-value  (Very Simple)
#--------------------------------------------
# if p-value < alpha : reject Ho
#    otherwise accept Ho