# Example 10-17

library(Rstat)

# Using 'bntest2.plot()' of Rstat Package : p with large sample
bntest2.plot(x=15, n=200, p0=0.1, alp=0.05, side="low")

# In case of double-sided test
bntest2.plot(x=15, n=200, p0=0.1, alp=0.05, side="two")

