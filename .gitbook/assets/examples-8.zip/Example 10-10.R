# Example 10-10

library(Rstat)

# meantest2.plot() : population variance unknown
xb <- 12.65
mu0 <- 12.5
sig <- 0.57
n <- 40
side <- "up"   # right-tail : "up", left-tail : "low", Double-Side : "two"

meantest2.plot(xb, mu0, sig, n, side=side)

# Critical Value of T : Tc
Tc <- qt(0.05, n-1, lower.tail=FALSE); Tc

#--------------------------------------------
# Decision Rule usign Critical Value
#--------------------------------------------
# (Right Tail Test)
#--------------------------------------------
# If To > Tc : reject Ho
#    otherwise accept Ho
#--------------------------------------------
# (Left Tail Test)
#--------------------------------------------
# If To < -Tc : reject Ho
#    otherwise accept Ho
#--------------------------------------------
# (Double-Sided Test)
#--------------------------------------------
# If To < -Tc or To > Tc : reject Ho
#    otherwise accept Ho
#--------------------------------------------

#--------------------------------------------
# Decision Rule using P-value  (Very Simple)
#--------------------------------------------
# if p-value < alpha : reject Ho
#    otherwise accept Ho