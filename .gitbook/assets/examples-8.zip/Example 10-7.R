# Example 10-7

library(Rstat)

# meantest1.plot()
xb <- 199.5
mu0 <- 200
sig <- 1.8
n <- 50
side <- "two"   # right-tail : "up", left-tail : "low", Double-Side : "two"

meantest1.plot(xb, mu0, sig, n, side=side)


# Critical Value of Z : Zc
qv <- qnorm(0.05/2, mu0, sig, lower.tail=FALSE)
Zc <- (qv - mu0) / sig; Zc

#--------------------------------------------
# Decision Rule usign Critical Value
#--------------------------------------------
# (Right Tail Test)
#--------------------------------------------
# If Zo > Zc : reject Ho
#    otherwise accept Ho
#--------------------------------------------
# (Left Tail Test)
#--------------------------------------------
# If Zo < -Zc : reject Ho
#    otherwise accept Ho
#--------------------------------------------
# (Double-Sided Test)
#--------------------------------------------
# If Zo < -Zc or Zo > Zc : reject Ho
#    otherwise accept Ho
#--------------------------------------------

#--------------------------------------------
# Decision Rule using P-value  (Very Simple)
#--------------------------------------------
# if p-value < alpha : reject Ho
#    otherwise accept Ho