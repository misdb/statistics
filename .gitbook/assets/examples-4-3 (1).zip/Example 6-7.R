# Example 6-7

library(Rstat)

# 1. Prob. Distribution of X
L <- 1.5
n <- 20

x <- 0:n
fx <- dpois(x, L)

# 2-3. Title of Plot and Using `disc.exp()` function for E(X), V(X), and Plot
disc.exp(x, fx, plot=TRUE)

# 4. p(X>=3)
# (Method 1) p(X>=3) = 1 - p(X<=2)
x <- 2
1 - sum(dpois(0:x, L))

# (Method 2) using `ppois()` function
x <-2
ppois(x, L, lower=FALSE)

# 5. Y = 10 * X = 20, L(Y) = 10 * L = 15 => Y ~ Poi(L=15)
dpois(20, 15)


