# Example 6-3

# 1. Prob. Distribution
n <- 20               # number of sample
p <- 0.03    

x <- 0:n              # range of random variable X
fx <- dbinom(x, n, p) # Prob. Distribution of X

# 2. E(X), V(X)
disc.exp(x, fx)

# 3. P(X=2) : 
x <- 2
dbinom(x, n, p)

# 4. p(X>=3)
x <- 3:n

# (Method 1) 1 - P(X<=2) 
x <- 0:2
1- sum(dbinom(x, n, p))

# (Method 2) using 'pbinom()' 
x <- 2
pbinom(x, n, p, lower=FALSE)



