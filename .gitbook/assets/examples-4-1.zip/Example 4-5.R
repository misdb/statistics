# Example 4-5

library(Rstat)

# Probability distribution function of X 
pdf <- function(x) 2* exp(-2*x)*(x>0)

# P(0<X<1)
integrate(pdf, 0, 1)[[1]]

