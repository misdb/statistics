# Example 4-1-2

library(Rstat)

# 1) Sample Space
S <- tosscoin2(3); S

# 2) definition of function index_T :
money <- function(x) {

                  i <- max(which(x=="T"))
                  if (i == -Inf)  i <- 0      # in case of x <- c("H", "H", "H")

                  if (i ==3) return(0)
                  else if (i == 2) return(300)
                  else if (i == 1) return(200+300)
                  else if (i == 0) return(100+200+300)
           }

# 3) Definition of X
X <- apply(S, 1, money); X

# 4) Prob. Mass Function
Y <- table(X)/nrow(S)

# 5) 
y <- data.frame(Y); y
x <- sort(unique(as.numeric(X))); x

disc.exp(x, y$Freq)