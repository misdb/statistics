# Example 4-3

library(Rstat)

# 1) Sample Space
S <- rolldie2(4)

# 2) definition of X
X <- apply(S, 1, sum)

# 3) prob. distribution of X
y <- round( table(X)/nrow(S), 2 ); y
plot(y, ylim = c(0, 0.12))


# ---------
# Probability distribution of X and Plot...
rolldie.sum(4)


