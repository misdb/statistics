# Example 4-4

#----------------------------
# [Method 1]
#----------------------------
library(Rstat)

# Probability distribution of X and Plot...
N <- 50;      # Number of Population
S <- 8;       # Number of Success
n <- 10;      # Number of Sample
hyp.sample(N, S, n)

# '? hyp.sample()' in the R console to find the help...
# Description : Probability Distribution of the Number of Successes from Finite Population

#----------------------------
# [Method 2]
#----------------------------
library(Rstat)

N <- 50;      # Number of Population
S <- 8;       # Number of Success
n <- 10;      # Number of Sample
x <- 0:10     # value of Random Variable X

# # Probability distribution of X
fx <- dhyper(x, S, N-S, n)          # hypergeometric distribution function

# Plot
pdf <- data.frame(x, round(fx,4))
plot(pdf, type="h")
