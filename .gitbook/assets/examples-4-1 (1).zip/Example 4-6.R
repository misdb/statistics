# Example 4-6

library(Rstat)

# number of T in 3 coins
N <- 3

# value of Random Variable X
x <- 0:3

# frequency of X
(freq <- choose(N, x))    # ? choose()

# function 'disc.cdf()' :
# cumulative distribution function and Plot
# of discrete random variable 
disc.cdf(x, freq, mt = "The Number of T in 3 Coins")