# Example 8-3

library(Rstat)

# 1. Cumulative Distribution of Standard Normal Distribution : Table & Graph
# 0~2.49, unit : 0.01, 10 columns

pv <- matrix(pnorm(0:299/100), ncol=10, byrow=T)
colnames(pv) <- 0:9/100; rownames(pv) <- 0:29/10

print(round(pv, 4))

# 2.Cumulative Probability of Standard Normail Distribution
zp <- seq(-2, 2, by=0.5)
snorm.cdf(zp)