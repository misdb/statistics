# Example 8-1

library(Rstat)

# parameters of Normal Distribution : function 'cont.spdf()'
mu <- c(0, 0, 2, 2)
sig <- c(1, 2, 1, 2)

cont.spdf("norm", -7, 7, mu, sig, xp=mu)