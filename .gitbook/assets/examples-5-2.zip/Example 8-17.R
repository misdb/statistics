# Example 8-17

# x-axis
x <- 100:300/100

# degree of freedom
df <- c(1:5, 10, 30, 100)

# probability
dcol <- rainbow(9)

win.graph(7, 5)
plot(x, pnorm(x)-pnorm(-x), type="l", lwd=2, col=dcol[1], 
     main="P(-x < X < x)", ylab="P(-x<X<x)", 
     ylim=c(0.5, 1), xlim=c(1, 3.2))
grid(col=3)

for (i in 1:8) lines(x, pt(x, df[i]) - pt(-x, df[i]),
                     type="l", lwd=2, col=dcol[9-i])
text(3, 1, labels="N(0,1)", cex=0.8, pos=4)
text(3, pt(3, df[1:4]) - pt(-3, df[1:4]), 
     labels=paste0("t(", df[1:4], ")"), 
     cex= 0.8, pos=4)

# computation of probability
x <- 2:6/2
pv <- NULL
for (i in 1:8) pv <- cbind(pv, pt(x, df[i]) - pt(-x, df[i]))
pv <- cbind(pv, pnorm(x) - pnorm(-x))
rownames(pv) <- x
colnames(pv) <- c(paste0("t(", df, ")"), "N(0,1)")
t(pv)
