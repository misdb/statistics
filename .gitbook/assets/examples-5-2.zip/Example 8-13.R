# Example 8-13

library(Rstat)

# df and cumulative prob.
nu <- c(5, 10, 30, 100)
p <- 0.95

# 1. quantile 'qchisq(p, nu)'
qchisq(p, nu)

# 2.
qchisq(p, nu) / nu



