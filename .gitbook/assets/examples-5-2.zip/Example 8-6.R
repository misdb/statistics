# Example 8-6

library(Rstat)

# qnorm(p, mean, sd)
qnorm(0.05, 10, 1.5)

10 + qnorm(0.05)*1.5
