# Example 8-4

library(Rstat)

# point of computing quantile using cumulative prob.
pv <- c(0.005, 0.01, 0.025, 0.05, 1:9/10, 0.95, 0.975, 0.99, 0.995)

# quantile of standard normal distribution : function 'snorm.quant()'
snorm.quant(pv, pv)
