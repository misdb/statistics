# Example 8-18

library(Rstat)

# F(8, 5) : fdist.sim()
fdist.sim(nu1=8, nu2=5)

# F(5,8) 
fdist.sim(nu1=5, nu2=8)

#
p <- c( 0.01, 0.025, 0.05, 5:9/10, 0.95, 0.975, 0.99)
LHS <- qf(p, 8, 5)
RHS <- 1/qf(1-p, 5, 8)
round(LHS-RHS, 9)          # LHS == RHS ?
