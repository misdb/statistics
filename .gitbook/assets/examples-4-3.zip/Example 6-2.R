# Example 6-2

# in case of (p = 0.2)
# number of trial(n), prob. of success(p), range of x
n <- 10; p <- 0.2; x <- 0:n

# prob. distribution function
fx <- dbinom(x, n, p)

# title of plot (mt) and using function 'disc.exp()'
mt1 <- paste0("B(10", p, ")")
disc.exp(x, fx, mt = mt1, plot=TRUE)

#--------------------------
# in case of p = c(0.2, 0.5, 0.8)

n <- 10; p <- c(0.2, 0.5, 0.8); x <- 0:n

# prob. distribution function
fx1 <- list()
for (i in 1:length(p)) fx1[[i]] <- dbinom(x, n, p[i])

# title of plot (mt) and using function 'disc.mexp()'
mt1 <- paste0("B(10", p, ")")
disc.mexp(x, fx1, mt = mt1, plot=TRUE)

