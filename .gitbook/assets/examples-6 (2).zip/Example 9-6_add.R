# Example 9-6

# Definition of Population (n=10)
n <- 10; mu <- 100; sig <- 10; N <- 10000

# Simulation : 10 Samples, Calculation of Statistics, N <- 10000
set.seed(9857)
zs <- NULL
for (k in 1:N) zs <- c(zs, sum((rnorm(n, mu, sig) - mu)^2)/sig^2)

# Definition of Chi-square Distribution
svd <- function(x) dchisq(x, n)

# Draw the Graph
win.graph(7,5)
hist(zs, breaks=seq(from=0, to=ceiling(max(zs)), length.out=50), prob=T,
     col=7, main="Distribution of Sum of Z-squares (n=10)", xlim=c(0, 35), ylab="f(x)")
curve(svd, 0, ceiling(max(zs)), lwd=2, col=2, add=T)


#--------------------
# chi.sim()
#--------------------

library(Rstat)

n <- 10               # sample size
m <- 100              # mean
si <- 10              # standard deviation

# simulation function : '? chi.sim()'
chi.sim(ns=n, mu=m, sig=si)
