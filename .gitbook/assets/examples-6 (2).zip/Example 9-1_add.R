# Example 9-1

library(Rstat)

# Distribution of Sample Mean (n=10)
n <- 10; mu <- 100; sig <- 10; N <- 10000

# Simulation : Sample Size(ns)=10, Calculation of Sample Means, N <- 10,000
set.seed(9857)
xb <- NULL
for (k in 1:N) xb <- c(xb, mean(rnorm(n, mu, sig)))

# Standardization of Sample Mean
zb <- (xb - mu) / sig * sqrt(n) 

# Definition of Population Distribution & Sample Mean Distribution
popd <- function(x) dnorm(x, mu, sig)
smd <- function(x) dnorm(x, mu, sig/sqrt(n))

# Plotting two graphs at the same time
par(mfrow=c(2,1))
hist(xb, breaks=seq(from=70, to=130, length.out=50),
     prob=T, col=7, 
     main = "Distribution of Sample Mean with sample size=10 from N(100,100)",
     ylab = "f(x)")
curve(popd, 70, 130, col=4, add=T)
curve(smd, 70, 130, col=2, add=T)

# Graph of Z distribution
hist(zb, breaks=seq(from=-4, to=4, length.out=50), 
     prob=T, col="cyan", 
     main="Distribution of the Standardized Smaple Mean",
     ylab="f(x)")
curve(dnorm, -4, 4, col=2, add=T)


#---------------------
# norm.sim() 
#---------------------
norm.sim(ns=10, mu=100, sig=10, N=10000)



