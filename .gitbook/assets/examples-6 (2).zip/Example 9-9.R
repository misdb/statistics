# Example 9-9

library(Rstat)

# degree of freedom, cumulative function
si1 <- sqrt(4)
si2 <- sqrt(49)
n1 <- 8
n2 <- 5

# funcion 'fdist.sim2()'
fdist.sim2(sig1 = si1, sig2 = si2, n1 = n1, n2 = n2)
