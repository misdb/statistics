# Example 9-6

library(Rstat)

n <- 10               # sample size
m <- 100              # mean
si <- 10              # standard deviation

# simulation function : '? chi.sim()'
chi.sim(ns=n, mu=m, sig=si)
