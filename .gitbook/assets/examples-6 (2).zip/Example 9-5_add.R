# Example 9-5

# Distribution of Sample Mean (n=10)
n <- 10; mu <- 100; sig <- 10; N <- 10000

# Simulation : sample means and sample standard deviation of 10 samples, N <- 10,000
set.seed(9857)
xb <- ss <- NULL
for (k in 1:N) { sam <- rnorm(n, mu, sig)
                 xb <- c(xb, mean(sam))
                 ss <- c(ss, sd(sam))  }

# Standardization of Sample Means
zb2 <- (xb - mu) / ss*sqrt(n)

# Definition of Sample Mean Distribution
smd2 <- function(x) dt(x, n-1)

# Draw the Graph
win.graph(7, 5)
hist(zb2, breaks=seq(from=-10, to=10, length.out=100),
     prob=T, col="cyan", xlim=c(-5, 5), 
     main="Distribution of Sample Mean Standardized with Sample SD",
     ylab="f(x)")
curve(smd2, -5, 5, lwd=2, col=2, add=T)
curve(dnorm, -5, 5, col=4, add=T)
legend("topright", c("t(9)", "N(0,1)"), lwd=c(2,1), col=c(2,4))



#------------------
# tdist.sim()
#------------------

library(Rstat)

n <- 10               # sample size
m <- 100              # mean
si <- 10              # standard deviation

# simulation function : 'tdist.sim()'
tdist.sim(ns=n, mu=m, sig=si)
