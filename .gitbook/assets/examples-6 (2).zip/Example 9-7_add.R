# Example 9-7

# Definition of the Population
n <- 10; mu <- 100; sig <- 10
N <- 10000

# Simulation : 10 Samples, Calculation of Statistics, N <- 10000
set.seed(9857)
zs2 <- NULL
for (k in 1:N) zs2 <- c(zs2, (n-1)*var(rnorm(n, mu, sig))/sig^2)

# Definition of Chi-square Distribution
svd2 <- function(x) dchisq(x, n-1)

# Draw the Graph
win.graph(7,5)
hist(zs2, breaks=seq(from=0, to=ceiling(max(zs2)), length.out=50), prob=T,
     col=7, main="Distribution of Tranformed Sample Variance (n=10)", ylab="f(x)")
curve(svd2, 0, ceiling(max(zs2)), lwd=2, col=2, add=T)

# in case of df = n 
curve(svd, 0, ceiling(max(zs2)), lwd=1, col=2, add=T)
legend("topright", c("Chi-square(9)", "Chi-square(10)"), lwd=c(2,1), col=c(2,4))



#------------------
# chi.sim()
#------------------

library(Rstat)

n <- 10               # sample size
m <- 100              # mean
si <- 10              # standard deviation

# simulation function : '? chi.sim()'
chi.sim(ns=n, mu=m, sig=si, muknow=FALSE)

#**** degree of freedom = (n-1) rather than (n) ****
