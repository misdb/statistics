# Example 9-4

library(Rstat)

# Definition of Calculating the Minimun Sample Size
spn <- function(k, alp) ceiling((qnorm(1-alp/2)/k)^2)

# Ranges of alpha and k
alp <- c(0.01, 0.05, 0.1)
kv <- (10:100)/100

# Draw Graphs (y-axis : log scale)
win.graph(7, 6)
plot(kv, spn(kv, alp[1]), type="l", log="y", lwd=2, col=2,
     ylim = c(1, spn(kv[1], alp[1])), main="Sample Size securing the k Sigma Error limit")
grid()
lines(kv, spn(kv, alp[2]), lwd=2, col=4)
lines(kv, spn(kv, alp[3]), lwd=2, col="green4")

# Displaying the legend
legend("topright", paste0("alpha=", alp), lwd=2, col=c(2, 4, "green4"))

# Exmaples of Example 9-3 Results
segments(0.4, 1, 0.4, spn(0.4, alp[2]), lty=2, col=6)
segments(0.1, spn(0.4, alp[2]), 0.4, spn(0.4, alp[2]), lty=2, col=6)
text(0.1, spn(0.4, alp[2]), labels=spn(0.4, alp[2]), col=4)


#------------------------
# norm.spn() function
#------------------------

# 3 levels of significance
alp <- c(0.01, 0.05, 0.1)
dcol <- c(2, 4, "green4")

# using function `norm.spn()`
norm.spn(kp=0.4, alp, dcol = dcol)

# in case of k=0.2 => sample size is increasing....
norm.spn(kp=0.2, alp, dcol = dcol)