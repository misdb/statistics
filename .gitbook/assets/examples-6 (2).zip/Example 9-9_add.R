# Example 9-9

# Definition of the Population
sig1 <- 2; sig2 <- 7

# Sampling n1=8, n2=5. N <- 10000
n1 <- 8; n2 <- 5; N <- 10000

set.seed(9857)
fs2 <- NULL

vratio <- function(n1, n2, s1, s2) {
          var(rnorm(n1, sd=s1))/s1^2/(var(rnorm(n2, sd=s2))/s2^2) }
for (k in 1:N) fs2 <- c(fs2, vratio(n1, n2, sig1, sig2))

# Definition of F-distribution
fd2 <- function(x) df(x, n1-1, n2-1)
fd1 <- function(x) df(x, n1, n2)

# Draw the Graph
win.graph(7,5)
hist(fs2, breaks=seq(from=0, to=ceiling(max(fs2)), length.out=800), prob=T,
     xlim=c(0, 10), col=7, 
     main="Distribution of Ratio of Sample Variance F(7,4)", ylab="f(x)")
curve(fd2, 0, 10, lwd=2, col=2, add=T)

# in case of df = (8,5) 
curve(fd1, 0, 7, lwd=1, col=4, add=T)
legend("topright", c("F(7,4)", "F(8,5)"), lwd=c(2,1), col=c(2,4))


#----------------
# fdis.sim()
#----------------

library(Rstat)

# degree of freedom, cumulative function
si1 <- sqrt(4)
si2 <- sqrt(49)
n1 <- 8
n2 <- 5

# funcion 'fdist.sim2()'
fdist.sim2(sig1 = si1, sig2 = si2, n1 = n1, n2 = n2)
